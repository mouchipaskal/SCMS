-- ============================================================
-- Smart Campus Management System - Database Setup
-- Run this entire script in MySQL Workbench as root
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_campus_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_campus_db;

-- ===================== SEMESTERS =====================
CREATE TABLE IF NOT EXISTS semesters (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    start_date DATE,
    end_date DATE,
    is_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===================== DEPARTMENTS =====================
CREATE TABLE IF NOT EXISTS departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    head_name VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===================== ROOMS =====================
CREATE TABLE IF NOT EXISTS rooms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_number VARCHAR(30) UNIQUE NOT NULL,
    building VARCHAR(100),
    capacity INT DEFAULT 30,
    room_type VARCHAR(50) DEFAULT 'Lecture Hall'
);

-- ===================== USERS =====================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(60) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    role ENUM('ADMIN','LECTURER','STUDENT') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    profile_photo VARCHAR(255),
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_role (role),
    INDEX idx_username (username)
);

-- ===================== STUDENTS =====================
CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
    student_number VARCHAR(30) UNIQUE NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    gender ENUM('Male','Female','Other'),
    date_of_birth DATE,
    email VARCHAR(120),
    phone VARCHAR(20),
    address TEXT,
    department_id INT,
    admission_year INT,
    photo_path VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    INDEX idx_department (department_id)
);

-- ===================== LECTURERS =====================
CREATE TABLE IF NOT EXISTS lecturers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE,
    staff_id VARCHAR(30) UNIQUE NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(120),
    phone VARCHAR(20),
    department_id INT,
    specialization VARCHAR(150),
    office_location VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- ===================== COURSES =====================
CREATE TABLE IF NOT EXISTS courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(30) UNIQUE NOT NULL,
    title VARCHAR(200) NOT NULL,
    credit_hours INT DEFAULT 3,
    department_id INT,
    semester_id INT,
    lecturer_id INT,
    prerequisite_id INT,
    description TEXT,
    max_students INT DEFAULT 50,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE SET NULL,
    FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE SET NULL,
    FOREIGN KEY (prerequisite_id) REFERENCES courses(id) ON DELETE SET NULL
);

-- ===================== REGISTRATIONS =====================
CREATE TABLE IF NOT EXISTS registrations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester_id INT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Active','Dropped','Completed') DEFAULT 'Active',
    UNIQUE KEY uq_registration (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE SET NULL
);

-- ===================== ATTENDANCE =====================
CREATE TABLE IF NOT EXISTS attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present','Absent','Late','Excused') DEFAULT 'Present',
    marked_by INT,
    notes VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_attendance (student_id, course_id, attendance_date),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (marked_by) REFERENCES lecturers(id) ON DELETE SET NULL
);

-- ===================== GRADES =====================
CREATE TABLE IF NOT EXISTS grades (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester_id INT,
    ca_score DECIMAL(5,2) DEFAULT 0,
    exam_score DECIMAL(5,2) DEFAULT 0,
    total_score DECIMAL(5,2) GENERATED ALWAYS AS (ca_score + exam_score) STORED,
    grade_letter VARCHAR(5),
    grade_points DECIMAL(3,1) DEFAULT 0,
    remarks VARCHAR(100),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_grade (student_id, course_id, semester_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE SET NULL
);

-- ===================== TIMETABLE =====================
CREATE TABLE IF NOT EXISTS timetable (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_id INT NOT NULL,
    room_id INT,
    semester_id INT,
    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL,
    FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE SET NULL
);

-- ===================== NOTIFICATIONS =====================
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('INFO','WARNING','ALERT','SUCCESS') DEFAULT 'INFO',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ===================== ACTIVITY LOGS =====================
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(255) NOT NULL,
    module VARCHAR(100),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Semesters
INSERT IGNORE INTO semesters (name, academic_year, start_date, end_date, is_active)
VALUES ('Semester 1 2024/2025', '2024/2025', '2024-09-01', '2025-01-31', TRUE),
       ('Semester 2 2024/2025', '2024/2025', '2025-02-01', '2025-06-30', FALSE);

-- Departments
INSERT IGNORE INTO departments (code, name, head_name) VALUES
('CS', 'Computer Science', 'Dr. Alan Turing'),
('EE', 'Electrical Engineering', 'Dr. Nikola Tesla'),
('BUS', 'Business Administration', 'Dr. Peter Drucker'),
('MED', 'Medical Sciences', 'Dr. Hippocrates');

-- Rooms
INSERT IGNORE INTO rooms (room_number, building, capacity, room_type) VALUES
('A101', 'Block A', 60, 'Lecture Hall'),
('A102', 'Block A', 40, 'Classroom'),
('B201', 'Block B', 30, 'Lab'),
('B202', 'Block B', 80, 'Lecture Hall'),
('C301', 'Block C', 25, 'Seminar Room');

-- Admin user (password: Admin@123)
INSERT IGNORE INTO users (username, password_hash, email, full_name, role)
VALUES ('admin', '$2a$12$pVs4vHlR8LGSZb3DQxRm8.bEv1E1cnQjLbV2Tgz8fvRr1DFDxfYKi',
        'admin@scms.edu', 'System Administrator', 'ADMIN');

-- Lecturer user (password: Lecturer@123)
INSERT IGNORE INTO users (username, password_hash, email, full_name, role)
VALUES ('lecturer1', '$2a$12$KYfBlzDwh4TXlocaasheOOP9EK/FfHJgdyTnoGufXvb/Znc4yNA3u',
        'lecturer1@scms.edu', 'Dr. John Williams', 'LECTURER');

-- Student user (password: Student@123)
INSERT IGNORE INTO users (username, password_hash, email, full_name, role)
VALUES ('student1', '$2a$12$92rBTrMSDzbEKMaN9NQTKuMn56RZVqqmybFHBKempUTsKMLc/fRn2',
        'student1@scms.edu', 'Alice Johnson', 'STUDENT');

-- Sample lecturer
INSERT IGNORE INTO lecturers (user_id, staff_id, full_name, email, department_id, specialization, office_location)
VALUES (2, 'LEC-001', 'Dr. John Williams', 'lecturer1@scms.edu', 1, 'Software Engineering', 'Block A, Room 105');

-- Sample student
INSERT IGNORE INTO students (user_id, student_number, full_name, gender, email, department_id, admission_year)
VALUES (3, 'SCM-2024-001', 'Alice Johnson', 'Female', 'student1@scms.edu', 1, 2024);

-- Sample courses
INSERT IGNORE INTO courses (course_code, title, credit_hours, department_id, semester_id, lecturer_id)
VALUES
('CS101', 'Introduction to Programming', 3, 1, 1, 1),
('CS201', 'Data Structures and Algorithms', 3, 1, 1, 1),
('CS301', 'Database Systems', 3, 1, 1, 1),
('CS401', 'Software Engineering', 3, 1, 1, 1),
('EE101', 'Circuit Analysis', 3, 2, 1, NULL);

-- ===================== QR SESSIONS =====================
CREATE TABLE IF NOT EXISTS qr_sessions (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    token       VARCHAR(20) UNIQUE NOT NULL,
    course_id   INT NOT NULL,
    session_date DATE NOT NULL,
    expires_at  TIMESTAMP NOT NULL,
    is_active   BOOLEAN DEFAULT TRUE,
    created_by  INT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id)  REFERENCES courses(id)   ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES lecturers(id) ON DELETE SET NULL
);

-- NOTE: Default passwords above are BCrypt hashes.
-- At first run, use: admin / Admin@123 (or run app which will hash on registration)
-- For simplicity during testing, you can also reset with plaintext
-- by replacing the hash with a new BCrypt hash from BCryptUtil.
