package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.AlertUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class CourseManagementController {

    @FXML private TextField searchField;
    @FXML private TableView<Course> coursesTable;
    @FXML private TableColumn<Course, String> codeCol;
    @FXML private TableColumn<Course, String> titleCol;
    @FXML private TableColumn<Course, Integer> creditsCol;
    @FXML private TableColumn<Course, String> deptCol;
    @FXML private TableColumn<Course, String> semesterCol;
    @FXML private TableColumn<Course, String> lecturerCol;

    @FXML private TextField courseCodeField;
    @FXML private TextField titleField;
    @FXML private TextField creditsField;
    @FXML private TextField maxStudentsField;
    @FXML private ComboBox<Department> deptCombo;
    @FXML private ComboBox<Semester> semesterCombo;
    @FXML private ComboBox<Lecturer> lecturerCombo;
    @FXML private TextArea descArea;
    @FXML private CheckBox isActiveCheck;
    @FXML private Label statusLabel;
    @FXML private Label totalLabel;

    private final CourseService courseService = new CourseService();
    private final DepartmentService deptService = new DepartmentService();
    private final SemesterService semesterService = new SemesterService();
    private final LecturerService lecturerService = new LecturerService();
    private Course selected;

    @FXML
    public void initialize() {
        setupTable();
        deptCombo.setItems(FXCollections.observableArrayList(deptService.getAll()));
        semesterCombo.setItems(FXCollections.observableArrayList(semesterService.getAll()));
        lecturerCombo.setItems(FXCollections.observableArrayList(lecturerService.getAll()));
        isActiveCheck.setSelected(true);
        creditsField.setText("3");
        maxStudentsField.setText("50");
        load();
        coursesTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> populateForm(neo)
        );
    }

    private void setupTable() {
        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("creditHours"));
        deptCol.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        semesterCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
        lecturerCol.setCellValueFactory(new PropertyValueFactory<>("lecturerName"));
    }

    private void load() {
        List<Course> list = courseService.getAll();
        coursesTable.setItems(FXCollections.observableArrayList(list));
        totalLabel.setText("Total: " + list.size());
    }

    private void populateForm(Course c) {
        if (c == null) return;
        selected = c;
        courseCodeField.setText(c.getCourseCode()); titleField.setText(c.getTitle());
        creditsField.setText(String.valueOf(c.getCreditHours()));
        maxStudentsField.setText(String.valueOf(c.getMaxStudents()));
        descArea.setText(c.getDescription());
        isActiveCheck.setSelected(c.isActive());
        deptCombo.getItems().stream().filter(d -> d.getId() == c.getDepartmentId()).findFirst().ifPresent(deptCombo::setValue);
        semesterCombo.getItems().stream().filter(s -> s.getId() == c.getSemesterId()).findFirst().ifPresent(semesterCombo::setValue);
        lecturerCombo.getItems().stream().filter(l -> l.getId() == c.getLecturerId()).findFirst().ifPresent(lecturerCombo::setValue);
    }

    @FXML private void handleSearch() {
        String kw = searchField.getText().trim();
        List<Course> r = kw.isEmpty() ? courseService.getAll() : courseService.search(kw);
        coursesTable.setItems(FXCollections.observableArrayList(r));
        totalLabel.setText("Found: " + r.size());
    }

    @FXML private void handleAdd() {
        if (titleField.getText().isEmpty() || courseCodeField.getText().isEmpty()) {
            setStatus("Course code and title are required."); return;
        }
        Course c = buildFromForm();
        if (c == null) return;
        if (courseService.add(c)) { setStatus("Course added."); clearForm(); load(); }
        else setStatus("Failed (code may be duplicate).");
    }

    @FXML private void handleUpdate() {
        if (selected == null) { setStatus("Select a course."); return; }
        Course c = buildFromForm();
        if (c == null) return;
        c.setId(selected.getId());
        if (courseService.update(c)) { setStatus("Course updated."); load(); }
        else setStatus("Update failed.");
    }

    @FXML private void handleDelete() {
        if (selected == null) { setStatus("Select a course."); return; }
        if (!AlertUtil.confirm("Delete Course", "Delete " + selected.getTitle() + "?")) return;
        if (courseService.delete(selected.getId())) { setStatus("Deleted."); clearForm(); selected = null; load(); }
        else setStatus("Cannot delete — course in use.");
    }

    @FXML private void handleClear() { clearForm(); }
    @FXML private void handleBack()  { SceneManager.switchTo("admin-dashboard"); }

    private Course buildFromForm() {
        try {
            Course c = new Course();
            c.setCourseCode(courseCodeField.getText().trim()); c.setTitle(titleField.getText().trim());
            c.setCreditHours(Integer.parseInt(creditsField.getText().trim()));
            c.setMaxStudents(maxStudentsField.getText().isEmpty() ? 50 : Integer.parseInt(maxStudentsField.getText().trim()));
            Department d = deptCombo.getValue(); c.setDepartmentId(d != null ? d.getId() : 0);
            Semester s = semesterCombo.getValue(); c.setSemesterId(s != null ? s.getId() : 0);
            Lecturer l = lecturerCombo.getValue(); c.setLecturerId(l != null ? l.getId() : 0);
            c.setDescription(descArea.getText() == null ? "" : descArea.getText().trim()); c.setActive(isActiveCheck.isSelected());
            return c;
        } catch (NumberFormatException e) { setStatus("Credits/max students must be numbers."); return null; }
    }

    private void clearForm() {
        courseCodeField.clear(); titleField.clear(); creditsField.setText("3");
        maxStudentsField.setText("50"); descArea.clear(); deptCombo.setValue(null);
        semesterCombo.setValue(null); lecturerCombo.setValue(null); isActiveCheck.setSelected(true);
        selected = null; statusLabel.setText("");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
