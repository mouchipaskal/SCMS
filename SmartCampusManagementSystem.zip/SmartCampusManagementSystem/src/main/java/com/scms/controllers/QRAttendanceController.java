package com.scms.controllers;

import com.scms.models.Course;
import com.scms.models.Lecturer;
import com.scms.models.QRSession;
import com.scms.models.User;
import com.scms.services.CourseService;
import com.scms.services.LecturerService;
import com.scms.services.QRAttendanceService;
import com.scms.utils.QRCodeUtil;
import com.scms.utils.SceneManager;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class QRAttendanceController {

    // ─── Lecturer: Generate QR ───────────────────────
    @FXML private ComboBox<Course>   courseCombo;
    @FXML private DatePicker         sessionDatePicker;
    @FXML private ComboBox<Integer>  durationCombo;
    @FXML private Button             generateBtn;
    @FXML private Button             deactivateBtn;

    // QR Display
    @FXML private ImageView          qrImageView;
    @FXML private Label              tokenLabel;
    @FXML private Label              courseInfoLabel;
    @FXML private Label              countdownLabel;
    @FXML private Label              scannedCountLabel;
    @FXML private Label              statusLabel;

    // Live scan list
    @FXML private ListView<String>   scannedList;

    private final QRAttendanceService qrService      = new QRAttendanceService();
    private final CourseService       courseService   = new CourseService();
    private final LecturerService     lecturerService = new LecturerService();

    private QRSession  activeSession;
    private Timeline   countdownTimeline;
    private ScheduledExecutorService liveRefresh;

    @FXML
    public void initialize() {
        durationCombo.setItems(FXCollections.observableArrayList(5, 10, 15, 20, 30));
        durationCombo.setValue(10);
        sessionDatePicker.setValue(LocalDate.now());
        deactivateBtn.setDisable(true);
        qrImageView.setFitWidth(300);
        qrImageView.setFitHeight(300);
        qrImageView.setPreserveRatio(true);

        User user = SceneManager.getCurrentUser();
        if (user != null && "LECTURER".equals(user.getRole())) {
            Lecturer lec = lecturerService.getByUserId(user.getId());
            if (lec != null) {
                List<Course> myCourses = courseService.getByLecturer(lec.getId());
                courseCombo.setItems(FXCollections.observableArrayList(myCourses));
            }
        } else {
            // Admin sees all courses
            courseCombo.setItems(FXCollections.observableArrayList(courseService.getAll()));
        }
    }

    @FXML
    private void handleGenerateQR() {
        Course course = courseCombo.getValue();
        if (course == null)         { setStatus("Select a course first."); return; }
        if (sessionDatePicker.getValue() == null) { setStatus("Select a date."); return; }

        stopLiveRefresh();
        stopCountdown();

        User user = SceneManager.getCurrentUser();
        int lecturerId = 0;
        if (user != null && "LECTURER".equals(user.getRole())) {
            Lecturer lec = lecturerService.getByUserId(user.getId());
            if (lec != null) lecturerId = lec.getId();
        }

        int durationMins = durationCombo.getValue() != null ? durationCombo.getValue() : 10;
        activeSession = qrService.createSession(course.getId(), lecturerId, sessionDatePicker.getValue(), durationMins);

        if (activeSession == null) { setStatus("Failed to create QR session."); return; }

        // Render QR code
        Image qrImage = QRCodeUtil.generateQRWithLabel(activeSession.getToken(), course.getCourseCode(), 360);
        qrImageView.setImage(qrImage);

        tokenLabel.setText(activeSession.getToken());
        courseInfoLabel.setText(course.getCourseCode() + " — " + course.getTitle());
        setStatus("QR session active for " + durationMins + " minutes.");

        generateBtn.setDisable(true);
        deactivateBtn.setDisable(false);

        startCountdown(activeSession.getExpiresAt());
        startLiveRefresh();
    }

    @FXML
    private void handleDeactivate() {
        if (activeSession != null) {
            qrService.deactivateSession(activeSession.getId());
            activeSession = null;
        }
        stopCountdown();
        stopLiveRefresh();
        generateBtn.setDisable(false);
        deactivateBtn.setDisable(true);
        countdownLabel.setText("Session ended");
        setStatus("Session deactivated.");
    }

    // ─── Countdown timer ────────────────────────────────
    private void startCountdown(LocalDateTime expiresAt) {
        countdownTimeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            long secs = ChronoUnit.SECONDS.between(LocalDateTime.now(), expiresAt);
            if (secs <= 0) {
                countdownLabel.setText("⏰ Expired");
                countdownLabel.setStyle("-fx-text-fill: #e53e3e;");
                stopCountdown();
                stopLiveRefresh();
                generateBtn.setDisable(false);
                deactivateBtn.setDisable(true);
                setStatus("QR session has expired.");
            } else {
                long mins = secs / 60;
                long sec  = secs % 60;
                countdownLabel.setText(String.format("%02d:%02d remaining", mins, sec));
                countdownLabel.setStyle(secs < 60
                    ? "-fx-text-fill: #e53e3e; -fx-font-weight: bold;"
                    : "-fx-text-fill: #38a169; -fx-font-weight: bold;");
            }
        }));
        countdownTimeline.setCycleCount(Timeline.INDEFINITE);
        countdownTimeline.play();
    }

    private void stopCountdown() {
        if (countdownTimeline != null) { countdownTimeline.stop(); countdownTimeline = null; }
    }

    // ─── Live scanned student refresh ───────────────────
    private void startLiveRefresh() {
        liveRefresh = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "qr-live-refresh");
            t.setDaemon(true);
            return t;
        });
        liveRefresh.scheduleAtFixedRate(() -> {
            if (activeSession == null) return;
            List<String> names  = qrService.getScannedStudents(activeSession.getId());
            int          count  = names.size();
            Platform.runLater(() -> {
                scannedList.setItems(FXCollections.observableArrayList(names));
                scannedCountLabel.setText("Students scanned: " + count);
            });
        }, 0, 3, TimeUnit.SECONDS);
    }

    private void stopLiveRefresh() {
        if (liveRefresh != null) { liveRefresh.shutdownNow(); liveRefresh = null; }
    }

    @FXML private void handleBack() {
        stopCountdown();
        stopLiveRefresh();
        User u = SceneManager.getCurrentUser();
        if (u == null) { SceneManager.switchTo("login"); return; }
        SceneManager.switchTo("LECTURER".equals(u.getRole()) ? "lecturer-dashboard" : "admin-dashboard");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
