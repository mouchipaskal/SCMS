package com.scms.controllers;

import com.scms.models.User;
import com.scms.services.UserService;
import com.scms.utils.ActivityLogger;
import com.scms.utils.SceneManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;
    @FXML private CheckBox showPasswordCheck;
    @FXML private TextField passwordVisible;

    private final UserService userService = new UserService();

    @FXML
    public void initialize() {
        errorLabel.setVisible(false);
        passwordVisible.setVisible(false);
        passwordVisible.setManaged(false);
        loginButton.setDefaultButton(true);

        // Sync password fields
        passwordVisible.textProperty().bindBidirectional(passwordField.textProperty());

        // Enter key on username moves to password
        usernameField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.TAB || e.getCode() == KeyCode.ENTER)
                passwordField.requestFocus();
        });
    }

    @FXML
    private void togglePasswordVisibility() {
        boolean show = showPasswordCheck.isSelected();
        passwordField.setVisible(!show);
        passwordField.setManaged(!show);
        passwordVisible.setVisible(show);
        passwordVisible.setManaged(show);
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter your username and password.");
            return;
        }

        loginButton.setDisable(true);
        loginButton.setText("Signing in...");

        User user = userService.login(username, password);
        loginButton.setDisable(false);
        loginButton.setText("Sign In");

        if (user == null) {
            showError("Invalid credentials or account is inactive.");
            passwordField.clear();
            return;
        }

        SceneManager.setCurrentUser(user);
        ActivityLogger.log(user.getId(), "User logged in", "Authentication");

        switch (user.getRole()) {
            case "ADMIN"    -> SceneManager.switchTo("admin-dashboard");
            case "LECTURER" -> SceneManager.switchTo("lecturer-dashboard");
            case "STUDENT"  -> SceneManager.switchTo("student-dashboard");
            default         -> showError("Unknown role. Contact administrator.");
        }
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }
}
