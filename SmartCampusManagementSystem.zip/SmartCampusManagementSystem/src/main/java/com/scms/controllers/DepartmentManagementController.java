package com.scms.controllers;

import com.scms.models.Department;
import com.scms.services.DepartmentService;
import com.scms.utils.AlertUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class DepartmentManagementController {

    @FXML private TableView<Department> deptTable;
    @FXML private TableColumn<Department, Integer> idCol;
    @FXML private TableColumn<Department, String> codeCol;
    @FXML private TableColumn<Department, String> nameCol;
    @FXML private TableColumn<Department, String> headCol;

    @FXML private TextField codeField;
    @FXML private TextField nameField;
    @FXML private TextField headField;
    @FXML private TextArea descArea;
    @FXML private Label statusLabel;

    private final DepartmentService service = new DepartmentService();
    private Department selected;

    @FXML
    public void initialize() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        codeCol.setCellValueFactory(new PropertyValueFactory<>("code"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        headCol.setCellValueFactory(new PropertyValueFactory<>("headName"));
        load();
        deptTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> {
                if (neo == null) return;
                selected = neo;
                codeField.setText(neo.getCode()); nameField.setText(neo.getName());
                headField.setText(neo.getHeadName()); descArea.setText(neo.getDescription());
            }
        );
    }

    private void load() {
        deptTable.setItems(FXCollections.observableArrayList(service.getAll()));
    }

    @FXML private void handleAdd() {
        if (nameField.getText().isEmpty() || codeField.getText().isEmpty()) { setStatus("Code and name required."); return; }
        Department d = build();
        if (service.add(d)) { setStatus("Department added."); clearForm(); load(); }
        else setStatus("Failed (code may be duplicate).");
    }

    @FXML private void handleUpdate() {
        if (selected == null) { setStatus("Select a department."); return; }
        Department d = build(); d.setId(selected.getId());
        if (service.update(d)) { setStatus("Updated."); load(); }
        else setStatus("Update failed.");
    }

    @FXML private void handleDelete() {
        if (selected == null) { setStatus("Select a department."); return; }
        if (!AlertUtil.confirm("Delete", "Delete department: " + selected.getName() + "?")) return;
        if (service.delete(selected.getId())) { setStatus("Deleted."); clearForm(); selected = null; load(); }
        else setStatus("Cannot delete — department in use.");
    }

    @FXML private void handleClear() { clearForm(); }
    @FXML private void handleBack()  { SceneManager.switchTo("admin-dashboard"); }

    private Department build() {
        Department d = new Department();
        d.setCode(codeField.getText().trim()); d.setName(nameField.getText().trim());
        d.setHeadName(headField.getText().trim()); d.setDescription(descArea.getText().trim());
        return d;
    }

    private void clearForm() {
        codeField.clear(); nameField.clear(); headField.clear(); descArea.clear();
        selected = null; statusLabel.setText("");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
