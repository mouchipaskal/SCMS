package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.AlertUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class RegistrationController {

    @FXML private TableView<Registration> regTable;
    @FXML private TableColumn<Registration, Integer> idCol;
    @FXML private TableColumn<Registration, String> studentCol;
    @FXML private TableColumn<Registration, String> courseCol;
    @FXML private TableColumn<Registration, String> semesterCol;
    @FXML private TableColumn<Registration, String> statusCol;
    @FXML private TableColumn<Registration, String> dateCol;

    @FXML private ComboBox<Student> studentCombo;
    @FXML private ComboBox<Course> courseCombo;
    @FXML private ComboBox<Semester> semesterCombo;
    @FXML private Label creditHoursLabel;
    @FXML private Label statusLabel;
    @FXML private Label totalLabel;

    private final RegistrationService regService = new RegistrationService();
    private final StudentService studentService = new StudentService();
    private final CourseService courseService = new CourseService();
    private final SemesterService semesterService = new SemesterService();
    private Registration selected;

    private static final int MAX_CREDIT_HOURS = 21;

    @FXML
    public void initialize() {
        setupTable(); loadAll();
        studentCombo.setItems(FXCollections.observableArrayList(studentService.getAll()));
        courseCombo.setItems(FXCollections.observableArrayList(courseService.getAll()));
        semesterCombo.setItems(FXCollections.observableArrayList(semesterService.getAll()));
        Semester active = semesterService.getActive();
        if (active != null) semesterCombo.setValue(active);

        studentCombo.valueProperty().addListener((obs, o, n) -> updateCreditHoursDisplay());
        semesterCombo.valueProperty().addListener((obs, o, n) -> updateCreditHoursDisplay());

        regTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> { if (neo != null) { selected = neo; setStatus("Selected registration #" + neo.getId()); } }
        );
    }

    private void setupTable() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        studentCol.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        courseCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCourseCode() + " - " + data.getValue().getCourseTitle()
            )
        );
        semesterCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(item.equals("Active") ? "-fx-text-fill: #38a169;" :
                         item.equals("Dropped") ? "-fx-text-fill: #e53e3e;" : "-fx-text-fill: #3182ce;");
            }
        });
        dateCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getRegistrationDate() != null
                    ? data.getValue().getRegistrationDate().toString().substring(0, 10)
                    : ""
            )
        );
    }

    private void loadAll() {
        List<Registration> list = regService.getAll();
        regTable.setItems(FXCollections.observableArrayList(list));
        totalLabel.setText("Total: " + list.size());
    }

    private void updateCreditHoursDisplay() {
        Student s = studentCombo.getValue();
        Semester sem = semesterCombo.getValue();
        if (s == null || sem == null) { creditHoursLabel.setText(""); return; }
        int taken = regService.getTotalCreditHours(s.getId(), sem.getId());
        creditHoursLabel.setText("Credit hours taken: " + taken + " / " + MAX_CREDIT_HOURS);
    }

    @FXML
    private void handleRegister() {
        Student s = studentCombo.getValue();
        Course c = courseCombo.getValue();
        Semester sem = semesterCombo.getValue();

        if (s == null) { setStatus("Select a student."); return; }
        if (c == null) { setStatus("Select a course."); return; }

        if (regService.alreadyRegistered(s.getId(), c.getId())) {
            setStatus("Student is already registered for this course."); return;
        }

        if (sem != null) {
            int taken = regService.getTotalCreditHours(s.getId(), sem.getId());
            if (taken + c.getCreditHours() > MAX_CREDIT_HOURS) {
                setStatus("Credit limit exceeded! Max " + MAX_CREDIT_HOURS + " credit hours per semester."); return;
            }
        }

        Registration r = new Registration();
        r.setStudentId(s.getId()); r.setCourseId(c.getId());
        r.setSemesterId(sem != null ? sem.getId() : 0);

        if (regService.register(r)) { setStatus("Registration successful."); loadAll(); updateCreditHoursDisplay(); }
        else setStatus("Registration failed.");
    }

    @FXML
    private void handleDrop() {
        if (selected == null) { setStatus("Select a registration to drop."); return; }
        if (!AlertUtil.confirm("Drop Course", "Drop this course registration?")) return;
        if (regService.drop(selected.getId())) { setStatus("Course dropped."); loadAll(); }
        else setStatus("Drop failed.");
    }

    @FXML private void handleBack() { SceneManager.switchTo("admin-dashboard"); }
    private void setStatus(String msg) { statusLabel.setText(msg); }
}
