package com.scms.controllers;

import com.scms.models.*;
import com.scms.reports.CSVExporter;
import com.scms.reports.PDFReportGenerator;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ReportsController {

    @FXML private ComboBox<Student> studentCombo;
    @FXML private BarChart<String, Number> gpaBarChart;
    @FXML private CategoryAxis gpaX;
    @FXML private NumberAxis gpaY;
    @FXML private PieChart gradePieChart;
    @FXML private Label statusLabel;

    private final StudentService studentService = new StudentService();
    private final GradeService gradeService = new GradeService();
    private final SemesterService semesterService = new SemesterService();

    @FXML
    public void initialize() {
        studentCombo.setItems(FXCollections.observableArrayList(studentService.getAll()));
        loadGpaChart();
        loadGradeDistribution();
    }

    private void loadGpaChart() {
        gpaBarChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("CGPA");
        List<Student> students = studentService.getAll();
        for (Student s : students.stream().limit(10).toList()) {
            double cgpa = gradeService.calculateCGPA(s.getId());
            series.getData().add(new XYChart.Data<>(s.getFullName().split(" ")[0], cgpa));
        }
        gpaBarChart.getData().add(series);
        gpaBarChart.setTitle("Student CGPA Overview");
    }

    private void loadGradeDistribution() {
        gradePieChart.getData().clear();
        // Aggregate all grades
        List<Grade> allGrades = studentService.getAll().stream()
            .flatMap(s -> gradeService.getByStudent(s.getId()).stream())
            .toList();

        Map<String, Long> byGrade = allGrades.stream()
            .filter(g -> g.getGradeLetter() != null)
            .collect(Collectors.groupingBy(Grade::getGradeLetter, Collectors.counting()));

        byGrade.forEach((grade, count) ->
            gradePieChart.getData().add(new PieChart.Data("Grade " + grade + " (" + count + ")", count))
        );
        gradePieChart.setTitle("Grade Distribution");
    }

    @FXML
    private void handleGenerateTranscript() {
        Student s = studentCombo.getValue();
        if (s == null) { setStatus("Select a student."); return; }
        PDFReportGenerator.generateTranscript(s.getId(), SceneManager.getPrimaryStage());
        setStatus("Transcript generated.");
    }

    @FXML
    private void handleExportStudentsCSV() {
        CSVExporter.exportStudents(studentService.getAll(), SceneManager.getPrimaryStage());
        setStatus("Students exported to CSV.");
    }

    @FXML
    private void handleExportGradesCSV() {
        Student s = studentCombo.getValue();
        if (s == null) { setStatus("Select a student for grade export."); return; }
        CSVExporter.exportGrades(gradeService.getByStudent(s.getId()), SceneManager.getPrimaryStage());
        setStatus("Grades exported to CSV.");
    }

    @FXML private void handleRefreshCharts() { loadGpaChart(); loadGradeDistribution(); }
    @FXML private void handleBack() { SceneManager.switchTo("admin-dashboard"); }
    private void setStatus(String msg) { statusLabel.setText(msg); }
}
