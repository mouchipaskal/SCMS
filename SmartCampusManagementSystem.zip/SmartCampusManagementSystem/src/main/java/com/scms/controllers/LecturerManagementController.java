package com.scms.controllers;

import com.scms.models.Department;
import com.scms.models.Lecturer;
import com.scms.models.User;
import com.scms.services.DepartmentService;
import com.scms.services.LecturerService;
import com.scms.services.UserService;
import com.scms.utils.ActivityLogger;
import com.scms.utils.AlertUtil;
import com.scms.utils.BCryptUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class LecturerManagementController {

    @FXML private TextField searchField;
    @FXML private TableView<Lecturer> lecturersTable;
    @FXML private TableColumn<Lecturer, Integer> idCol;
    @FXML private TableColumn<Lecturer, String> staffIdCol;
    @FXML private TableColumn<Lecturer, String> nameCol;
    @FXML private TableColumn<Lecturer, String> specCol;
    @FXML private TableColumn<Lecturer, String> deptCol;
    @FXML private TableColumn<Lecturer, String> emailCol;
    @FXML private TableColumn<Lecturer, String> phoneCol;

    @FXML private TextField staffIdField;
    @FXML private TextField fullNameField;
    @FXML private TextField emailField;
    @FXML private TextField phoneField;
    @FXML private TextField specField;
    @FXML private TextField officeField;
    @FXML private ComboBox<Department> deptCombo;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private CheckBox isActiveCheck;
    @FXML private Label statusLabel;
    @FXML private Label totalLabel;

    private final LecturerService lecturerService = new LecturerService();
    private final DepartmentService departmentService = new DepartmentService();
    private final UserService userService = new UserService();
    private Lecturer selectedLecturer;

    @FXML
    public void initialize() {
        setupTable();
        deptCombo.setItems(FXCollections.observableArrayList(departmentService.getAll()));
        isActiveCheck.setSelected(true);
        loadLecturers();
        lecturersTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> populateForm(neo)
        );
    }

    private void setupTable() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        staffIdCol.setCellValueFactory(new PropertyValueFactory<>("staffId"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        specCol.setCellValueFactory(new PropertyValueFactory<>("specialization"));
        deptCol.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
    }

    private void loadLecturers() {
        List<Lecturer> list = lecturerService.getAll();
        lecturersTable.setItems(FXCollections.observableArrayList(list));
        totalLabel.setText("Total: " + list.size());
    }

    private void populateForm(Lecturer l) {
        if (l == null) return;
        selectedLecturer = l;
        staffIdField.setText(l.getStaffId());
        fullNameField.setText(l.getFullName());
        emailField.setText(l.getEmail());
        phoneField.setText(l.getPhone());
        specField.setText(l.getSpecialization());
        officeField.setText(l.getOfficeLocation());
        isActiveCheck.setSelected(l.isActive());
        deptCombo.getItems().stream()
            .filter(d -> d.getId() == l.getDepartmentId())
            .findFirst().ifPresent(deptCombo::setValue);
        usernameField.clear(); passwordField.clear();
        setStatus("Selected: " + l.getFullName());
    }

    @FXML private void handleSearch() {
        String kw = searchField.getText().trim();
        List<Lecturer> result = kw.isEmpty() ? lecturerService.getAll() : lecturerService.search(kw);
        lecturersTable.setItems(FXCollections.observableArrayList(result));
        totalLabel.setText("Found: " + result.size());
    }

    @FXML private void handleAdd() {
        if (fullNameField.getText().isEmpty() || staffIdField.getText().isEmpty()) {
            setStatus("Staff ID and full name are required."); return;
        }
        Lecturer l = buildFromForm();
        if (!usernameField.getText().isEmpty() && !passwordField.getText().isEmpty()) {
            if (userService.usernameExists(usernameField.getText())) { setStatus("Username already exists."); return; }
            User u = new User();
            u.setUsername(usernameField.getText()); u.setPasswordHash(BCryptUtil.hash(passwordField.getText()));
            u.setEmail(emailField.getText()); u.setFullName(fullNameField.getText()); u.setRole("LECTURER");
            if (!userService.createUser(u)) { setStatus("Failed to create user account."); return; }
            l.setUserId(u.getId());
        }
        if (lecturerService.add(l)) {
            setStatus("Lecturer added."); clearForm(); loadLecturers();
            User cur = SceneManager.getCurrentUser();
            if (cur != null) ActivityLogger.log(cur.getId(), "Added lecturer: " + l.getFullName(), "Lecturer Management");
        } else setStatus("Failed to add lecturer.");
    }

    @FXML private void handleUpdate() {
        if (selectedLecturer == null) { setStatus("Select a lecturer to update."); return; }
        Lecturer l = buildFromForm();
        l.setId(selectedLecturer.getId()); l.setUserId(selectedLecturer.getUserId());
        if (lecturerService.update(l)) { setStatus("Lecturer updated."); loadLecturers(); }
        else setStatus("Update failed.");
    }

    @FXML private void handleDelete() {
        if (selectedLecturer == null) { setStatus("Select a lecturer to delete."); return; }
        if (!AlertUtil.confirm("Delete", "Delete " + selectedLecturer.getFullName() + "?")) return;
        if (lecturerService.delete(selectedLecturer.getId())) {
            setStatus("Deleted."); clearForm(); selectedLecturer = null; loadLecturers();
        } else setStatus("Delete failed.");
    }

    @FXML private void handleClear() { clearForm(); }
    @FXML private void handleBack()  { SceneManager.switchTo("admin-dashboard"); }

    private Lecturer buildFromForm() {
        Lecturer l = new Lecturer();
        l.setStaffId(staffIdField.getText().trim()); l.setFullName(fullNameField.getText().trim());
        l.setEmail(emailField.getText().trim()); l.setPhone(phoneField.getText().trim());
        l.setSpecialization(specField.getText().trim()); l.setOfficeLocation(officeField.getText().trim());
        Department d = deptCombo.getValue();
        l.setDepartmentId(d != null ? d.getId() : 0);
        l.setActive(isActiveCheck.isSelected());
        return l;
    }

    private void clearForm() {
        staffIdField.clear(); fullNameField.clear(); emailField.clear(); phoneField.clear();
        specField.clear(); officeField.clear(); deptCombo.setValue(null);
        usernameField.clear(); passwordField.clear(); isActiveCheck.setSelected(true);
        selectedLecturer = null; statusLabel.setText("");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
