package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;

public class AttendanceController {

    @FXML private ComboBox<Course> courseCombo;
    @FXML private DatePicker datePicker;
    @FXML private TableView<Attendance> attendanceTable;
    @FXML private TableColumn<Attendance, String> studentCol;
    @FXML private TableColumn<Attendance, String> statusCol;
    @FXML private TableColumn<Attendance, String> notesCol;
    @FXML private ComboBox<String> statusCombo;
    @FXML private TextField notesField;
    @FXML private Label statusLabel;
    @FXML private Label percentageLabel;
    @FXML private ComboBox<String> bulkStatusCombo;

    private final AttendanceService attendanceService = new AttendanceService();
    private final CourseService courseService = new CourseService();
    private final RegistrationService regService = new RegistrationService();
    private Attendance selected;

    @FXML
    public void initialize() {
        courseCombo.setItems(FXCollections.observableArrayList(courseService.getAll()));
        statusCombo.setItems(FXCollections.observableArrayList("Present", "Absent", "Late", "Excused"));
        bulkStatusCombo.setItems(FXCollections.observableArrayList("Present", "Absent"));
        statusCombo.setValue("Present");
        datePicker.setValue(LocalDate.now());

        studentCol.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "Present" -> "-fx-text-fill: #38a169;";
                    case "Absent"  -> "-fx-text-fill: #e53e3e;";
                    case "Late"    -> "-fx-text-fill: #dd6b20;";
                    default        -> "-fx-text-fill: #3182ce;";
                });
            }
        });
        notesCol.setCellValueFactory(new PropertyValueFactory<>("notes"));

        attendanceTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> {
                if (neo == null) return;
                selected = neo;
                statusCombo.setValue(neo.getStatus());
                notesField.setText(neo.getNotes());
            }
        );
    }

    @FXML
    private void handleLoad() {
        Course c = courseCombo.getValue();
        LocalDate date = datePicker.getValue();
        if (c == null || date == null) { setStatus("Select course and date."); return; }

        List<Registration> registrations = regService.getByCourse(c.getId());
        List<Attendance> existing = attendanceService.getByCourse(c.getId(), date);

        // Merge: for each registered student, check if attendance exists
        List<Attendance> combined = registrations.stream().map(r -> {
            Attendance found = existing.stream()
                .filter(a -> a.getStudentId() == r.getStudentId())
                .findFirst().orElseGet(() -> {
                    Attendance a = new Attendance();
                    a.setStudentId(r.getStudentId());
                    a.setCourseId(c.getId());
                    a.setStudentName(r.getStudentName());
                    a.setAttendanceDate(date);
                    a.setStatus("Present");
                    return a;
                });
            if (found.getStudentName() == null) found.setStudentName(r.getStudentName());
            return found;
        }).toList();

        attendanceTable.setItems(FXCollections.observableArrayList(combined));
        setStatus("Loaded " + combined.size() + " students.");
    }

    @FXML
    private void handleMark() {
        if (selected == null) { setStatus("Select a student row."); return; }
        selected.setStatus(statusCombo.getValue());
        selected.setNotes(notesField.getText());
        selected.setAttendanceDate(datePicker.getValue());
        if (attendanceService.markAttendance(selected)) {
            attendanceTable.refresh();
            setStatus("Marked: " + selected.getStudentName() + " — " + selected.getStatus());
        } else setStatus("Failed to mark attendance.");
    }

    @FXML
    private void handleMarkAll() {
        String bulk = bulkStatusCombo.getValue();
        if (bulk == null) { setStatus("Choose bulk status."); return; }
        Course c = courseCombo.getValue();
        LocalDate date = datePicker.getValue();
        if (c == null || date == null) return;

        attendanceTable.getItems().forEach(a -> {
            a.setStatus(bulk); a.setAttendanceDate(date);
            attendanceService.markAttendance(a);
        });
        attendanceTable.refresh();
        setStatus("All marked as: " + bulk);
    }

    @FXML
    private void handleCheckPercentage() {
        if (selected == null || courseCombo.getValue() == null) { setStatus("Select student and course."); return; }
        double pct = attendanceService.getAttendancePercentage(selected.getStudentId(), courseCombo.getValue().getId());
        percentageLabel.setText(String.format("Attendance: %.1f%%", pct));
    }

    @FXML private void handleQRAttendance() { SceneManager.switchTo("qr-attendance"); }

    @FXML private void handleBack() {
        User u = SceneManager.getCurrentUser();
        if (u == null) { SceneManager.switchTo("login"); return; }
        SceneManager.switchTo(switch (u.getRole()) {
            case "ADMIN" -> "admin-dashboard";
            case "LECTURER" -> "lecturer-dashboard";
            default -> "student-dashboard";
        });
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
