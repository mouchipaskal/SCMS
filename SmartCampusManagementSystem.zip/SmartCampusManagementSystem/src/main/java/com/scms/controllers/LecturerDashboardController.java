package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class LecturerDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label specLabel;
    @FXML private Label officeLabel;
    @FXML private Label deptLabel;
    @FXML private Label courseCountLabel;
    @FXML private TableView<Course> coursesTable;
    @FXML private TableColumn<Course, String> codeCol;
    @FXML private TableColumn<Course, String> titleCol;
    @FXML private TableColumn<Course, Integer> creditsCol;
    @FXML private TableColumn<Course, String> semCol;

    private final LecturerService lecturerService = new LecturerService();
    private final CourseService courseService = new CourseService();
    private Lecturer currentLecturer;

    @FXML
    public void initialize() {
        User user = SceneManager.getCurrentUser();
        currentLecturer = lecturerService.getByUserId(user.getId());

        if (currentLecturer != null) {
            welcomeLabel.setText("Welcome, " + currentLecturer.getFullName());
            specLabel.setText(currentLecturer.getSpecialization());
            officeLabel.setText(currentLecturer.getOfficeLocation());
            deptLabel.setText(currentLecturer.getDepartmentName());
        } else {
            welcomeLabel.setText("Welcome, " + user.getFullName());
        }

        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("creditHours"));
        semCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
        loadCourses();
    }

    private void loadCourses() {
        if (currentLecturer == null) return;
        List<Course> courses = courseService.getByLecturer(currentLecturer.getId());
        coursesTable.setItems(FXCollections.observableArrayList(courses));
        courseCountLabel.setText(String.valueOf(courses.size()));
    }

    @FXML private void goToAttendance()    { SceneManager.switchTo("attendance-management"); }
    @FXML private void goToQRAttendance()  { SceneManager.switchTo("qr-attendance"); }
    @FXML private void goToGrades()        { SceneManager.switchTo("grade-management"); }
    @FXML private void goToTimetable()     { SceneManager.switchTo("timetable-management"); }
    @FXML private void goToNotifications() { SceneManager.switchTo("notifications"); }
    @FXML private void goToSettings()      { SceneManager.switchTo("settings"); }
    @FXML private void handleRefresh()     { loadCourses(); }
    @FXML private void handleLogout() {
        SceneManager.setCurrentUser(null);
        SceneManager.switchTo("login");
    }
}
