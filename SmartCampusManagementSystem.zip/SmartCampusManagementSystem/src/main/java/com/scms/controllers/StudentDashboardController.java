package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class StudentDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label studentNumLabel;
    @FXML private Label deptLabel;
    @FXML private Label cgpaLabel;
    @FXML private Label registrationCountLabel;
    @FXML private TableView<Registration> registrationsTable;
    @FXML private TableColumn<Registration, String> courseCol;
    @FXML private TableColumn<Registration, String> semesterCol;
    @FXML private TableColumn<Registration, String> statusCol;
    @FXML private TableView<Grade> gradesTable;
    @FXML private TableColumn<Grade, String> gradeCodeCol;
    @FXML private TableColumn<Grade, String> gradeTitleCol;
    @FXML private TableColumn<Grade, Double> gradeTotal;
    @FXML private TableColumn<Grade, String> gradeLetterCol;

    private final StudentService studentService = new StudentService();
    private final RegistrationService regService = new RegistrationService();
    private final GradeService gradeService = new GradeService();
    private Student currentStudent;

    @FXML
    public void initialize() {
        User user = SceneManager.getCurrentUser();
        currentStudent = studentService.getByUserId(user.getId());

        if (currentStudent != null) {
            welcomeLabel.setText("Welcome, " + currentStudent.getFullName());
            studentNumLabel.setText(currentStudent.getStudentNumber());
            deptLabel.setText(currentStudent.getDepartmentName() != null ? currentStudent.getDepartmentName() : "N/A");
            double cgpa = gradeService.calculateCGPA(currentStudent.getId());
            cgpaLabel.setText(String.format("%.2f", cgpa));
        } else {
            welcomeLabel.setText("Welcome, " + user.getFullName());
        }

        setupRegistrationsTable();
        setupGradesTable();
        loadData();
    }

    private void setupRegistrationsTable() {
        courseCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCourseCode() + " - " + data.getValue().getCourseTitle()
            )
        );
        semesterCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
    }

    private void setupGradesTable() {
        gradeCodeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        gradeTitleCol.setCellValueFactory(new PropertyValueFactory<>("courseTitle"));
        gradeTotal.setCellValueFactory(new PropertyValueFactory<>("totalScore"));
        gradeLetterCol.setCellValueFactory(new PropertyValueFactory<>("gradeLetter"));
    }

    private void loadData() {
        if (currentStudent == null) return;
        List<Registration> regs = regService.getByStudent(currentStudent.getId());
        registrationsTable.setItems(FXCollections.observableArrayList(regs));
        registrationCountLabel.setText(String.valueOf(regs.size()));

        List<Grade> grades = gradeService.getByStudent(currentStudent.getId());
        gradesTable.setItems(FXCollections.observableArrayList(grades));
    }

    @FXML private void goToQRAttendance()  { SceneManager.switchTo("student-qr-attendance"); }
    @FXML private void goToNotifications() { SceneManager.switchTo("notifications"); }
    @FXML private void goToSettings()      { SceneManager.switchTo("settings"); }
    @FXML private void handleRefresh()     { loadData(); }
    @FXML private void handleLogout() {
        SceneManager.setCurrentUser(null);
        SceneManager.switchTo("login");
    }
}
