package com.scms.controllers;

import com.scms.models.User;
import com.scms.services.UserService;
import com.scms.utils.AlertUtil;
import com.scms.utils.SceneManager;
import com.scms.utils.ValidationUtil;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class SettingsController {

    @FXML private Label usernameLabel;
    @FXML private Label emailLabel;
    @FXML private Label roleLabel;
    @FXML private TextField fullNameField;
    @FXML private TextField phoneField;
    @FXML private PasswordField currentPassField;
    @FXML private PasswordField newPassField;
    @FXML private PasswordField confirmPassField;
    @FXML private ToggleButton darkModeToggle;
    @FXML private Label statusLabel;

    private final UserService userService = new UserService();

    @FXML
    public void initialize() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        usernameLabel.setText(u.getUsername());
        emailLabel.setText(u.getEmail());
        roleLabel.setText(u.getRole());
        fullNameField.setText(u.getFullName());
        phoneField.setText(u.getPhone() != null ? u.getPhone() : "");
        darkModeToggle.setSelected(SceneManager.isDarkMode());
        darkModeToggle.setText(SceneManager.isDarkMode() ? "Dark Mode ON" : "Dark Mode OFF");
    }

    @FXML
    private void handleToggleDarkMode() {
        boolean dark = darkModeToggle.isSelected();
        SceneManager.setDarkMode(dark);
        darkModeToggle.setText(dark ? "Dark Mode ON" : "Dark Mode OFF");
        setStatus("Theme changed to " + (dark ? "dark" : "light") + " mode.");
    }

    @FXML
    private void handleSaveProfile() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        u.setFullName(fullNameField.getText().trim());
        u.setPhone(phoneField.getText().trim());
        if (userService.updateUser(u)) {
            setStatus("Profile updated successfully.");
            SceneManager.setCurrentUser(u);
        } else setStatus("Failed to update profile.");
    }

    @FXML
    private void handleChangePassword() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        String current = currentPassField.getText();
        String newPw   = newPassField.getText();
        String confirm = confirmPassField.getText();

        if (current.isEmpty() || newPw.isEmpty() || confirm.isEmpty()) {
            setStatus("All password fields are required."); return;
        }
        if (!newPw.equals(confirm)) { setStatus("New passwords do not match."); return; }
        if (!ValidationUtil.isStrongPassword(newPw)) {
            setStatus("Password must be 8+ characters with uppercase and number."); return;
        }

        User verified = userService.login(u.getUsername(), current);
        if (verified == null) { setStatus("Current password is incorrect."); return; }

        if (userService.changePassword(u.getId(), newPw)) {
            setStatus("Password changed successfully.");
            currentPassField.clear(); newPassField.clear(); confirmPassField.clear();
        } else setStatus("Failed to change password.");
    }

    @FXML private void handleBack() {
        User u = SceneManager.getCurrentUser();
        if (u == null) { SceneManager.switchTo("login"); return; }
        SceneManager.switchTo(switch (u.getRole()) {
            case "ADMIN" -> "admin-dashboard";
            case "LECTURER" -> "lecturer-dashboard";
            default -> "student-dashboard";
        });
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
