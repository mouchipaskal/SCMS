package com.scms.controllers;

import com.scms.models.Notification;
import com.scms.models.User;
import com.scms.services.NotificationService;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class NotificationsController {

    @FXML private TableView<Notification> notifTable;
    @FXML private TableColumn<Notification, String> titleCol;
    @FXML private TableColumn<Notification, String> typeCol;
    @FXML private TableColumn<Notification, String> msgCol;
    @FXML private TableColumn<Notification, String> timeCol;
    @FXML private TableColumn<Notification, Boolean> readCol;
    @FXML private TextArea messageArea;
    @FXML private Label totalLabel;
    @FXML private Label unreadLabel;

    // Broadcast (admin only)
    @FXML private TextField broadcastTitleField;
    @FXML private TextArea broadcastMsgArea;
    @FXML private ComboBox<String> broadcastTypeCombo;

    private final NotificationService service = new NotificationService();
    private Notification selected;

    @FXML
    public void initialize() {
        if (broadcastTypeCombo != null)
            broadcastTypeCombo.setItems(FXCollections.observableArrayList("INFO", "WARNING", "ALERT", "SUCCESS"));

        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        typeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "WARNING" -> "-fx-text-fill: #dd6b20;";
                    case "ALERT"   -> "-fx-text-fill: #e53e3e;";
                    case "SUCCESS" -> "-fx-text-fill: #38a169;";
                    default        -> "-fx-text-fill: #3182ce;";
                });
            }
        });
        msgCol.setCellValueFactory(new PropertyValueFactory<>("message"));
        timeCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCreatedAt() != null
                    ? data.getValue().getCreatedAt().toString().replace("T", " ").substring(0, 16)
                    : ""
            )
        );
        readCol.setCellValueFactory(new PropertyValueFactory<>("read"));
        readCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); return; }
                setText(item ? "Read" : "Unread");
                setStyle(item ? "" : "-fx-text-fill: #e53e3e; -fx-font-weight: bold;");
            }
        });

        notifTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> {
                if (neo == null) return;
                selected = neo;
                messageArea.setText(neo.getMessage());
                service.markRead(neo.getId());
                neo.setRead(true);
                notifTable.refresh();
                loadCounts();
            }
        );
        loadNotifications();
    }

    private void loadNotifications() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        List<Notification> list = service.getByUser(u.getId());
        notifTable.setItems(FXCollections.observableArrayList(list));
        loadCounts();
    }

    private void loadCounts() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        int unread = service.countUnread(u.getId());
        totalLabel.setText("Total: " + notifTable.getItems().size());
        unreadLabel.setText("Unread: " + unread);
    }

    @FXML private void handleMarkAllRead() {
        User u = SceneManager.getCurrentUser();
        if (u == null) return;
        service.markAllRead(u.getId());
        loadNotifications();
    }

    @FXML private void handleRefresh() { loadNotifications(); }

    @FXML private void handleBroadcast() {
        if (broadcastTitleField == null || broadcastMsgArea == null) return;
        String title = broadcastTitleField.getText().trim();
        String msg   = broadcastMsgArea.getText().trim();
        String type  = broadcastTypeCombo.getValue() != null ? broadcastTypeCombo.getValue() : "INFO";
        if (title.isEmpty() || msg.isEmpty()) return;
        service.broadcast(title, msg, type);
        broadcastTitleField.clear(); broadcastMsgArea.clear();
        loadNotifications();
    }

    @FXML private void handleBack() {
        User u = SceneManager.getCurrentUser();
        if (u == null) { SceneManager.switchTo("login"); return; }
        SceneManager.switchTo(switch (u.getRole()) {
            case "ADMIN" -> "admin-dashboard";
            case "LECTURER" -> "lecturer-dashboard";
            default -> "student-dashboard";
        });
    }
}
