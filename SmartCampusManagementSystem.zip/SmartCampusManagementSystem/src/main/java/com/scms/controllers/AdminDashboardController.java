package com.scms.controllers;

import com.scms.models.ActivityLog;
import com.scms.models.User;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AdminDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label totalStudentsLabel;
    @FXML private Label totalLecturersLabel;
    @FXML private Label totalCoursesLabel;
    @FXML private Label totalRegistrationsLabel;
    @FXML private Label activeSemesterLabel;
    @FXML private Label currentPageLabel;

    // Charts
    @FXML private PieChart deptPieChart;
    @FXML private BarChart<String, Number> enrollmentBarChart;
    @FXML private CategoryAxis barChartX;
    @FXML private NumberAxis barChartY;

    // Activity log table
    @FXML private TableView<ActivityLog> activityTable;
    @FXML private TableColumn<ActivityLog, String> logUserCol;
    @FXML private TableColumn<ActivityLog, String> logActionCol;
    @FXML private TableColumn<ActivityLog, String> logModuleCol;
    @FXML private TableColumn<ActivityLog, String> logTimeCol;

    private final StudentService studentService         = new StudentService();
    private final LecturerService lecturerService       = new LecturerService();
    private final CourseService courseService           = new CourseService();
    private final RegistrationService regService        = new RegistrationService();
    private final SemesterService semesterService       = new SemesterService();
    private final ActivityLogService logService         = new ActivityLogService();
    private final DepartmentService departmentService   = new DepartmentService();

    @FXML
    public void initialize() {
        User user = SceneManager.getCurrentUser();
        welcomeLabel.setText("Welcome back, " + user.getFullName());

        loadStats();
        loadCharts();
        setupActivityTable();
        loadActivityLog();
    }

    private void loadStats() {
        totalStudentsLabel.setText(String.valueOf(studentService.countAll()));
        totalLecturersLabel.setText(String.valueOf(lecturerService.countAll()));
        totalCoursesLabel.setText(String.valueOf(courseService.countAll()));
        totalRegistrationsLabel.setText(String.valueOf(regService.countAll()));
        var active = semesterService.getActive();
        activeSemesterLabel.setText(active != null ? active.getName() : "None Active");
    }

    private void loadCharts() {
        // Pie chart: students per department
        var students = studentService.getAll();
        Map<String, Long> byDept = students.stream()
            .filter(s -> s.getDepartmentName() != null)
            .collect(Collectors.groupingBy(s -> s.getDepartmentName(), Collectors.counting()));

        deptPieChart.setData(FXCollections.observableArrayList(
            byDept.entrySet().stream()
                .map(e -> new PieChart.Data(e.getKey(), e.getValue()))
                .collect(Collectors.toList())
        ));
        deptPieChart.setTitle("Students by Department");

        // Bar chart: courses per department
        var courses = courseService.getAll();
        Map<String, Long> coursesByDept = courses.stream()
            .filter(c -> c.getDepartmentName() != null)
            .collect(Collectors.groupingBy(c -> c.getDepartmentName(), Collectors.counting()));

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Courses");
        coursesByDept.forEach((dept, count) ->
            series.getData().add(new XYChart.Data<>(dept, count))
        );
        enrollmentBarChart.getData().add(series);
        enrollmentBarChart.setTitle("Courses per Department");
    }

    private void setupActivityTable() {
        logUserCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        logActionCol.setCellValueFactory(new PropertyValueFactory<>("action"));
        logModuleCol.setCellValueFactory(new PropertyValueFactory<>("module"));
        logTimeCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCreatedAt() != null
                    ? data.getValue().getCreatedAt().toString().replace("T", " ").substring(0, 19)
                    : ""
            )
        );
    }

    private void loadActivityLog() {
        List<ActivityLog> logs = logService.getAll(20);
        activityTable.setItems(FXCollections.observableArrayList(logs));
    }

    // Navigation
    @FXML private void goToStudents()       { navigate("student-management", "Student Management"); }
    @FXML private void goToLecturers()      { navigate("lecturer-management", "Lecturer Management"); }
    @FXML private void goToDepartments()    { navigate("department-management", "Department Management"); }
    @FXML private void goToCourses()        { navigate("course-management", "Course Management"); }
    @FXML private void goToRegistrations()  { navigate("registration-management", "Course Registrations"); }
    @FXML private void goToAttendance()     { navigate("attendance-management", "Attendance Management"); }
    @FXML private void goToGrades()         { navigate("grade-management", "Grade Management"); }
    @FXML private void goToTimetable()      { navigate("timetable-management", "Timetable Management"); }
    @FXML private void goToNotifications()  { navigate("notifications", "Notifications"); }
    @FXML private void goToReports()        { navigate("reports", "Reports & Analytics"); }
    @FXML private void goToSettings()       { navigate("settings", "Settings"); }

    @FXML private void handleRefresh() {
        loadStats();
        loadActivityLog();
        enrollmentBarChart.getData().clear();
        deptPieChart.getData().clear();
        loadCharts();
    }

    @FXML private void handleLogout() {
        SceneManager.setCurrentUser(null);
        SceneManager.switchTo("login");
    }

    private void navigate(String view, String title) {
        if (currentPageLabel != null) currentPageLabel.setText(title);
        SceneManager.switchTo(view);
    }
}
