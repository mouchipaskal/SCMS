package com.scms.controllers;

import com.scms.models.Department;
import com.scms.models.Student;
import com.scms.models.User;
import com.scms.reports.CSVExporter;
import com.scms.services.DepartmentService;
import com.scms.services.StudentService;
import com.scms.services.UserService;
import com.scms.utils.ActivityLogger;
import com.scms.utils.AlertUtil;
import com.scms.utils.BCryptUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;

public class StudentManagementController {

    @FXML private TextField searchField;
    @FXML private TableView<Student> studentsTable;
    @FXML private TableColumn<Student, Integer> idCol;
    @FXML private TableColumn<Student, String> numCol;
    @FXML private TableColumn<Student, String> nameCol;
    @FXML private TableColumn<Student, String> genderCol;
    @FXML private TableColumn<Student, String> deptCol;
    @FXML private TableColumn<Student, String> emailCol;
    @FXML private TableColumn<Student, String> phoneCol;
    @FXML private TableColumn<Student, Integer> yearCol;
    @FXML private TableColumn<Student, Boolean> activeCol;

    // Form
    @FXML private TextField studentNumField;
    @FXML private TextField fullNameField;
    @FXML private ComboBox<String> genderCombo;
    @FXML private DatePicker dobPicker;
    @FXML private TextField emailField;
    @FXML private TextField phoneField;
    @FXML private TextArea addressArea;
    @FXML private ComboBox<Department> deptCombo;
    @FXML private TextField admissionYearField;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private CheckBox isActiveCheck;
    @FXML private Label statusLabel;
    @FXML private Label totalLabel;

    private final StudentService studentService = new StudentService();
    private final DepartmentService departmentService = new DepartmentService();
    private final UserService userService = new UserService();
    private Student selectedStudent;

    @FXML
    public void initialize() {
        setupTable();
        genderCombo.setItems(FXCollections.observableArrayList("Male", "Female", "Other"));
        deptCombo.setItems(FXCollections.observableArrayList(departmentService.getAll()));
        isActiveCheck.setSelected(true);
        loadStudents();

        studentsTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> populateForm(neo)
        );
    }

    private void setupTable() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        numCol.setCellValueFactory(new PropertyValueFactory<>("studentNumber"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
        deptCol.setCellValueFactory(new PropertyValueFactory<>("departmentName"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        yearCol.setCellValueFactory(new PropertyValueFactory<>("admissionYear"));
        activeCol.setCellValueFactory(new PropertyValueFactory<>("active"));
        activeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); return; }
                setText(item ? "Active" : "Inactive");
                setStyle(item ? "-fx-text-fill: #38a169;" : "-fx-text-fill: #e53e3e;");
            }
        });
    }

    private void loadStudents() {
        List<Student> list = studentService.getAll();
        studentsTable.setItems(FXCollections.observableArrayList(list));
        totalLabel.setText("Total: " + list.size());
    }

    private void populateForm(Student s) {
        if (s == null) return;
        selectedStudent = s;
        studentNumField.setText(s.getStudentNumber());
        fullNameField.setText(s.getFullName());
        genderCombo.setValue(s.getGender());
        dobPicker.setValue(s.getDateOfBirth());
        emailField.setText(s.getEmail());
        phoneField.setText(s.getPhone());
        addressArea.setText(s.getAddress());
        admissionYearField.setText(String.valueOf(s.getAdmissionYear()));
        isActiveCheck.setSelected(s.isActive());
        deptCombo.getItems().stream()
            .filter(d -> d.getId() == s.getDepartmentId())
            .findFirst().ifPresent(deptCombo::setValue);
        usernameField.clear(); passwordField.clear();
        setStatus("Selected: " + s.getFullName());
    }

    @FXML
    private void handleSearch() {
        String kw = searchField.getText().trim();
        List<Student> result = kw.isEmpty() ? studentService.getAll() : studentService.search(kw);
        studentsTable.setItems(FXCollections.observableArrayList(result));
        totalLabel.setText("Found: " + result.size());
    }

    @FXML
    private void handleAdd() {
        if (fullNameField.getText().isEmpty() || studentNumField.getText().isEmpty()) {
            setStatus("Student number and full name are required.");
            return;
        }
        Student s = buildFromForm();
        if (s == null) return;

        // Create user account if provided
        if (!usernameField.getText().isEmpty() && !passwordField.getText().isEmpty()) {
            if (userService.usernameExists(usernameField.getText())) { setStatus("Username already exists."); return; }
            User u = new User();
            u.setUsername(usernameField.getText()); u.setPasswordHash(BCryptUtil.hash(passwordField.getText()));
            u.setEmail(emailField.getText()); u.setFullName(fullNameField.getText()); u.setRole("STUDENT");
            if (!userService.createUser(u)) { setStatus("Failed to create user account."); return; }
            s.setUserId(u.getId());
        }

        if (studentService.add(s)) {
            setStatus("Student added successfully.");
            clearForm(); loadStudents();
            User cur = SceneManager.getCurrentUser();
            if (cur != null) ActivityLogger.log(cur.getId(), "Added student: " + s.getFullName(), "Student Management");
        } else setStatus("Failed to add student.");
    }

    @FXML
    private void handleUpdate() {
        if (selectedStudent == null) { setStatus("Select a student to update."); return; }
        Student s = buildFromForm();
        if (s == null) return;
        s.setId(selectedStudent.getId()); s.setUserId(selectedStudent.getUserId());
        if (studentService.update(s)) {
            setStatus("Student updated."); loadStudents();
        } else setStatus("Update failed.");
    }

    @FXML
    private void handleDelete() {
        if (selectedStudent == null) { setStatus("Select a student to delete."); return; }
        if (!AlertUtil.confirm("Delete Student", "Delete " + selectedStudent.getFullName() + "? This cannot be undone.")) return;
        if (studentService.delete(selectedStudent.getId())) {
            setStatus("Student deleted."); clearForm(); selectedStudent = null; loadStudents();
        } else setStatus("Delete failed.");
    }

    @FXML private void handleClear()   { clearForm(); }
    @FXML private void handleBack()    { SceneManager.switchTo("admin-dashboard"); }

    @FXML
    private void handleExportCSV() {
        CSVExporter.exportStudents(studentService.getAll(), SceneManager.getPrimaryStage());
        setStatus("Exported to CSV.");
    }

    private Student buildFromForm() {
        try {
            Student s = new Student();
            s.setStudentNumber(studentNumField.getText().trim());
            s.setFullName(fullNameField.getText().trim());
            s.setGender(genderCombo.getValue());
            s.setDateOfBirth(dobPicker.getValue());
            s.setEmail(emailField.getText().trim());
            s.setPhone(phoneField.getText().trim());
            s.setAddress(addressArea.getText().trim());
            Department d = deptCombo.getValue();
            s.setDepartmentId(d != null ? d.getId() : 0);
            s.setAdmissionYear(admissionYearField.getText().isEmpty() ? 0 : Integer.parseInt(admissionYearField.getText().trim()));
            s.setActive(isActiveCheck.isSelected());
            return s;
        } catch (NumberFormatException e) { setStatus("Admission year must be a number."); return null; }
    }

    private void clearForm() {
        studentNumField.clear(); fullNameField.clear(); genderCombo.setValue(null);
        dobPicker.setValue(null); emailField.clear(); phoneField.clear();
        addressArea.clear(); admissionYearField.clear(); deptCombo.setValue(null);
        usernameField.clear(); passwordField.clear(); isActiveCheck.setSelected(true);
        selectedStudent = null; statusLabel.setText("");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
