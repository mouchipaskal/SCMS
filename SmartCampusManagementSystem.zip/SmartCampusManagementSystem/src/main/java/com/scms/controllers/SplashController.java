package com.scms.controllers;

import com.scms.threads.NotificationThread;
import com.scms.utils.SceneManager;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.util.Duration;

public class SplashController {

    @FXML private ProgressBar progressBar;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        String[] steps = {
            "Initializing database...",
            "Loading modules...",
            "Starting notification service...",
            "Ready!"
        };

        Timeline tl = new Timeline();
        for (int i = 0; i < steps.length; i++) {
            final int idx = i;
            final double progress = (idx + 1.0) / steps.length;
            tl.getKeyFrames().add(new KeyFrame(Duration.millis(600 * (idx + 1)),
                e -> {
                    statusLabel.setText(steps[idx]);
                    progressBar.setProgress(progress);
                    if (idx == steps.length - 1) {
                        NotificationThread.start();
                        SceneManager.switchTo("login");
                    }
                }
            ));
        }
        tl.play();
    }
}
