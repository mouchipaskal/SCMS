package com.scms.controllers;

import com.scms.models.*;
import com.scms.services.*;
import com.scms.utils.AlertUtil;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalTime;
import java.util.List;

public class TimetableController {

    @FXML private ComboBox<Semester> semesterCombo;
    @FXML private TableView<Timetable> timetableTable;
    @FXML private TableColumn<Timetable, String> dayCol;
    @FXML private TableColumn<Timetable, String> timeCol;
    @FXML private TableColumn<Timetable, String> courseCol;
    @FXML private TableColumn<Timetable, String> lecturerCol;
    @FXML private TableColumn<Timetable, String> roomCol;
    @FXML private TableColumn<Timetable, String> semCol;

    @FXML private ComboBox<Course> courseCombo;
    @FXML private ComboBox<Room> roomCombo;
    @FXML private ComboBox<String> dayCombo;
    @FXML private TextField startTimeField;
    @FXML private TextField endTimeField;
    @FXML private Label statusLabel;
    @FXML private Label conflictLabel;

    private final TimetableService timetableService = new TimetableService();
    private final SemesterService semesterService = new SemesterService();
    private final CourseService courseService = new CourseService();
    private final RoomService roomService = new RoomService();
    private final LecturerService lecturerService = new LecturerService();
    private Timetable selected;

    @FXML
    public void initialize() {
        setupTable();
        semesterCombo.setItems(FXCollections.observableArrayList(semesterService.getAll()));
        courseCombo.setItems(FXCollections.observableArrayList(courseService.getAll()));
        roomCombo.setItems(FXCollections.observableArrayList(roomService.getAll()));
        dayCombo.setItems(FXCollections.observableArrayList(
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
        ));
        Semester active = semesterService.getActive();
        if (active != null) semesterCombo.setValue(active);
        loadTimetable();
        timetableTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> populateForm(neo)
        );
    }

    private void setupTable() {
        dayCol.setCellValueFactory(new PropertyValueFactory<>("dayOfWeek"));
        timeCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(data.getValue().getTimeRange())
        );
        courseCol.setCellValueFactory(data ->
            new javafx.beans.property.SimpleStringProperty(
                data.getValue().getCourseCode() + " - " + data.getValue().getCourseTitle()
            )
        );
        lecturerCol.setCellValueFactory(new PropertyValueFactory<>("lecturerName"));
        roomCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        semCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
    }

    private void loadTimetable() {
        Semester sem = semesterCombo.getValue();
        List<Timetable> list = sem != null ? timetableService.getBySemester(sem.getId()) : timetableService.getAll();
        timetableTable.setItems(FXCollections.observableArrayList(list));
    }

    private void populateForm(Timetable t) {
        if (t == null) return;
        selected = t;
        dayCombo.setValue(t.getDayOfWeek());
        startTimeField.setText(t.getStartTime() != null ? t.getStartTime().toString() : "");
        endTimeField.setText(t.getEndTime() != null ? t.getEndTime().toString() : "");
        courseCombo.getItems().stream().filter(c -> c.getId() == t.getCourseId()).findFirst().ifPresent(courseCombo::setValue);
        roomCombo.getItems().stream().filter(r -> r.getId() == t.getRoomId()).findFirst().ifPresent(roomCombo::setValue);
    }

    @FXML private void handleFilter() { loadTimetable(); }

    @FXML
    private void handleAdd() {
        Timetable t = buildFromForm();
        if (t == null) return;

        // Conflict check
        Course c = courseCombo.getValue();
        int lecturerId = 0;
        if (c != null) {
            var lec = lecturerService.getById(c.getLecturerId());
            if (lec != null) lecturerId = lec.getId();
        }
        Room r = roomCombo.getValue();
        int roomId = r != null ? r.getId() : 0;

        if (timetableService.hasConflict(lecturerId, roomId, t.getDayOfWeek(), t.getStartTime(), t.getEndTime(), -1)) {
            conflictLabel.setText("CONFLICT DETECTED: Lecturer or room is already booked at this time.");
            return;
        }
        conflictLabel.setText("");

        if (timetableService.add(t)) { setStatus("Added to timetable."); clearForm(); loadTimetable(); }
        else setStatus("Failed to add.");
    }

    @FXML
    private void handleUpdate() {
        if (selected == null) { setStatus("Select a row."); return; }
        Timetable t = buildFromForm();
        if (t == null) return;
        t.setId(selected.getId());
        if (timetableService.update(t)) { setStatus("Updated."); loadTimetable(); }
        else setStatus("Update failed.");
    }

    @FXML
    private void handleDelete() {
        if (selected == null) { setStatus("Select a row to delete."); return; }
        if (!AlertUtil.confirm("Delete", "Remove this timetable entry?")) return;
        if (timetableService.delete(selected.getId())) { setStatus("Deleted."); clearForm(); selected = null; loadTimetable(); }
        else setStatus("Delete failed.");
    }

    @FXML private void handleClear() { clearForm(); }
    @FXML private void handleBack()  {
        User u = SceneManager.getCurrentUser();
        SceneManager.switchTo(u != null && u.getRole().equals("ADMIN") ? "admin-dashboard" : "lecturer-dashboard");
    }

    private Timetable buildFromForm() {
        try {
            if (courseCombo.getValue() == null || dayCombo.getValue() == null || startTimeField.getText().isEmpty() || endTimeField.getText().isEmpty()) {
                setStatus("All fields required."); return null;
            }
            Timetable t = new Timetable();
            t.setCourseId(courseCombo.getValue().getId());
            Room r = roomCombo.getValue(); t.setRoomId(r != null ? r.getId() : 0);
            Semester sem = semesterCombo.getValue(); t.setSemesterId(sem != null ? sem.getId() : 0);
            t.setDayOfWeek(dayCombo.getValue());
            t.setStartTime(LocalTime.parse(startTimeField.getText().trim()));
            t.setEndTime(LocalTime.parse(endTimeField.getText().trim()));
            return t;
        } catch (Exception e) { setStatus("Time format must be HH:mm (e.g. 09:00)."); return null; }
    }

    private void clearForm() {
        courseCombo.setValue(null); roomCombo.setValue(null); dayCombo.setValue(null);
        startTimeField.clear(); endTimeField.clear(); selected = null;
        statusLabel.setText(""); conflictLabel.setText("");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
