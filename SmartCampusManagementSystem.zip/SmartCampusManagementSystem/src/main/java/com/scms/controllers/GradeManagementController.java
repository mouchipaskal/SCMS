package com.scms.controllers;

import com.scms.models.*;
import com.scms.reports.CSVExporter;
import com.scms.services.*;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class GradeManagementController {

    @FXML private ComboBox<Course> courseCombo;
    @FXML private ComboBox<Student> studentCombo;
    @FXML private TableView<Grade> gradeTable;
    @FXML private TableColumn<Grade, String> studentCol;
    @FXML private TableColumn<Grade, String> courseCol;
    @FXML private TableColumn<Grade, Double> caCol;
    @FXML private TableColumn<Grade, Double> examCol;
    @FXML private TableColumn<Grade, Double> totalCol;
    @FXML private TableColumn<Grade, String> gradeCol;
    @FXML private TableColumn<Grade, Double> gpCol;
    @FXML private TableColumn<Grade, String> semesterCol;

    @FXML private TextField caField;
    @FXML private TextField examField;
    @FXML private TextField remarksField;
    @FXML private ComboBox<Semester> semesterCombo;
    @FXML private Label gradePreviewLabel;
    @FXML private Label gpaLabel;
    @FXML private Label cgpaLabel;
    @FXML private Label statusLabel;

    private final GradeService gradeService = new GradeService();
    private final CourseService courseService = new CourseService();
    private final StudentService studentService = new StudentService();
    private final SemesterService semesterService = new SemesterService();
    private Grade selected;

    @FXML
    public void initialize() {
        courseCombo.setItems(FXCollections.observableArrayList(courseService.getAll()));
        studentCombo.setItems(FXCollections.observableArrayList(studentService.getAll()));
        semesterCombo.setItems(FXCollections.observableArrayList(semesterService.getAll()));
        Semester active = semesterService.getActive();
        if (active != null) semesterCombo.setValue(active);

        setupTable();

        // Live grade preview
        caField.textProperty().addListener((obs, o, n) -> updatePreview());
        examField.textProperty().addListener((obs, o, n) -> updatePreview());

        gradeTable.getSelectionModel().selectedItemProperty().addListener(
            (obs, old, neo) -> populateGradeForm(neo)
        );
    }

    private void setupTable() {
        studentCol.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        courseCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));
        caCol.setCellValueFactory(new PropertyValueFactory<>("caScore"));
        examCol.setCellValueFactory(new PropertyValueFactory<>("examScore"));
        totalCol.setCellValueFactory(new PropertyValueFactory<>("totalScore"));
        gradeCol.setCellValueFactory(new PropertyValueFactory<>("gradeLetter"));
        gradeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                setStyle(switch (item) {
                    case "A" -> "-fx-text-fill: #38a169; -fx-font-weight: bold;";
                    case "B" -> "-fx-text-fill: #3182ce; -fx-font-weight: bold;";
                    case "C" -> "-fx-text-fill: #dd6b20; -fx-font-weight: bold;";
                    case "D" -> "-fx-text-fill: #d69e2e; -fx-font-weight: bold;";
                    default  -> "-fx-text-fill: #e53e3e; -fx-font-weight: bold;";
                });
            }
        });
        gpCol.setCellValueFactory(new PropertyValueFactory<>("gradePoints"));
        semesterCol.setCellValueFactory(new PropertyValueFactory<>("semesterName"));
    }

    private void updatePreview() {
        try {
            double ca   = caField.getText().isEmpty() ? 0 : Double.parseDouble(caField.getText());
            double exam = examField.getText().isEmpty() ? 0 : Double.parseDouble(examField.getText());
            double total = ca + exam;
            String letter = Grade.computeGrade(total);
            double gp = Grade.gradeToPoints(letter);
            gradePreviewLabel.setText(String.format("Total: %.1f  |  Grade: %s  |  Points: %.1f", total, letter, gp));
        } catch (NumberFormatException e) {
            gradePreviewLabel.setText("Invalid score values");
        }
    }

    private void populateGradeForm(Grade g) {
        if (g == null) return;
        selected = g;
        caField.setText(String.valueOf(g.getCaScore()));
        examField.setText(String.valueOf(g.getExamScore()));
        remarksField.setText(g.getRemarks());
        studentCombo.getItems().stream().filter(s -> s.getId() == g.getStudentId()).findFirst().ifPresent(studentCombo::setValue);
        courseCombo.getItems().stream().filter(c -> c.getId() == g.getCourseId()).findFirst().ifPresent(courseCombo::setValue);
    }

    @FXML
    private void handleLoadByCourse() {
        Course c = courseCombo.getValue();
        if (c == null) { setStatus("Select a course."); return; }
        List<Grade> list = gradeService.getByCourse(c.getId());
        gradeTable.setItems(FXCollections.observableArrayList(list));
        setStatus("Loaded " + list.size() + " grades.");
    }

    @FXML
    private void handleLoadByStudent() {
        Student s = studentCombo.getValue();
        if (s == null) { setStatus("Select a student."); return; }
        List<Grade> list = gradeService.getByStudent(s.getId());
        gradeTable.setItems(FXCollections.observableArrayList(list));
        Semester sem = semesterCombo.getValue();
        if (sem != null) {
            double gpa = gradeService.calculateGPA(s.getId(), sem.getId());
            gpaLabel.setText(String.format("Semester GPA: %.2f", gpa));
        }
        double cgpa = gradeService.calculateCGPA(s.getId());
        cgpaLabel.setText(String.format("CGPA: %.2f", cgpa));
        setStatus("Loaded grades for " + s.getFullName());
    }

    @FXML
    private void handleSaveGrade() {
        Student s = studentCombo.getValue();
        Course c = courseCombo.getValue();
        if (s == null || c == null) { setStatus("Select student and course."); return; }
        try {
            double ca   = Double.parseDouble(caField.getText().trim());
            double exam = Double.parseDouble(examField.getText().trim());
            if (ca < 0 || ca > 40)   { setStatus("CA score must be 0-40."); return; }
            if (exam < 0 || exam > 60) { setStatus("Exam score must be 0-60."); return; }
            Grade g = new Grade();
            g.setStudentId(s.getId()); g.setCourseId(c.getId());
            Semester sem = semesterCombo.getValue();
            g.setSemesterId(sem != null ? sem.getId() : 0);
            g.setCaScore(ca); g.setExamScore(exam);
            g.setRemarks(remarksField.getText().trim());
            if (gradeService.saveGrade(g)) { setStatus("Grade saved."); handleLoadByCourse(); }
            else setStatus("Save failed.");
        } catch (NumberFormatException e) { setStatus("Enter valid numeric scores."); }
    }

    @FXML
    private void handleExportCSV() {
        List<Grade> list = gradeTable.getItems();
        if (list.isEmpty()) { setStatus("No grades to export."); return; }
        CSVExporter.exportGrades(list, SceneManager.getPrimaryStage());
        setStatus("Exported.");
    }

    @FXML private void handleBack() {
        User u = SceneManager.getCurrentUser();
        SceneManager.switchTo(u != null && u.getRole().equals("LECTURER") ? "lecturer-dashboard" : "admin-dashboard");
    }

    private void setStatus(String msg) { statusLabel.setText(msg); }
}
