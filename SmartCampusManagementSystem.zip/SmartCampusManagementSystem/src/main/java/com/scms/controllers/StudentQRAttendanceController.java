package com.scms.controllers;

import com.scms.models.Course;
import com.scms.models.QRSession;
import com.scms.models.Student;
import com.scms.models.User;
import com.scms.services.CourseService;
import com.scms.services.QRAttendanceService;
import com.scms.services.StudentService;
import com.scms.utils.SceneManager;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.List;

public class StudentQRAttendanceController {

    @FXML private Label  welcomeLabel;
    @FXML private Label  studentInfoLabel;

    // Manual code entry
    @FXML private TextField  tokenField;
    @FXML private Button     submitBtn;
    @FXML private Label      resultLabel;

    // Course selector (to auto-look up open QR session)
    @FXML private ComboBox<Course> courseCombo;
    @FXML private Label            sessionStatusLabel;
    @FXML private Button           checkSessionBtn;

    // History
    @FXML private ListView<String> historyList;

    private final QRAttendanceService qrService     = new QRAttendanceService();
    private final StudentService      studentService = new StudentService();
    private final CourseService       courseService  = new CourseService();

    private Student currentStudent;

    @FXML
    public void initialize() {
        User user = SceneManager.getCurrentUser();
        currentStudent = studentService.getByUserId(user.getId());

        if (currentStudent != null) {
            welcomeLabel.setText("QR Attendance — " + currentStudent.getFullName());
            studentInfoLabel.setText("Student: " + currentStudent.getStudentNumber()
                + "   Dept: " + (currentStudent.getDepartmentName() != null ? currentStudent.getDepartmentName() : "N/A"));
        } else {
            welcomeLabel.setText("QR Attendance");
            studentInfoLabel.setText("Profile not linked. Contact admin.");
            submitBtn.setDisable(true);
        }

        // Load student's registered courses for session lookup
        if (currentStudent != null) {
            List<Course> courses = courseService.getAll();
            courseCombo.setItems(FXCollections.observableArrayList(courses));
        }

        resultLabel.setVisible(false);
    }

    @FXML
    private void handleSubmitToken() {
        if (currentStudent == null) {
            showResult("ERROR: Your student profile is not linked to your account.", false);
            return;
        }
        String token = tokenField.getText().trim().toUpperCase();
        if (token.isEmpty()) {
            showResult("Please enter the QR code shown by your lecturer.", false);
            return;
        }

        submitBtn.setDisable(true);
        submitBtn.setText("Submitting...");

        String result = qrService.submitQRAttendance(token, currentStudent.getId());

        submitBtn.setDisable(false);
        submitBtn.setText("Submit Attendance");

        boolean success = result.startsWith("SUCCESS");
        showResult(formatResult(result), success);

        if (success) {
            tokenField.clear();
            refreshHistory();
        }
    }

    @FXML
    private void handleCheckSession() {
        Course c = courseCombo.getValue();
        if (c == null) { sessionStatusLabel.setText("Select a course."); return; }
        QRSession session = qrService.getActiveSessionForCourse(c.getId(), LocalDate.now());
        if (session == null) {
            sessionStatusLabel.setText("No active QR session for " + c.getCourseCode() + " today.");
            sessionStatusLabel.setStyle("-fx-text-fill: #e53e3e;");
        } else if (session.isExpired()) {
            sessionStatusLabel.setText("Session found but it has expired.");
            sessionStatusLabel.setStyle("-fx-text-fill: #dd6b20;");
        } else {
            long mins = java.time.temporal.ChronoUnit.MINUTES.between(
                java.time.LocalDateTime.now(), session.getExpiresAt());
            sessionStatusLabel.setText("✓ Active session for " + c.getCourseCode() + " — " + mins + " min left. Enter the code shown on screen.");
            sessionStatusLabel.setStyle("-fx-text-fill: #38a169; -fx-font-weight: bold;");
            // Pre-fill token field if found automatically
            tokenField.setText(session.getToken());
        }
    }

    private void refreshHistory() {
        // Show the student's recent attendance activity (last 5 items as strings)
        // Since AttendanceService.getByStudent returns Attendance objects, we format them
        new Thread(() -> {
            var records = new com.scms.services.AttendanceService().getByStudent(currentStudent.getId());
            List<String> lines = records.stream()
                .limit(15)
                .map(a -> String.format("%-22s  %-10s  %s",
                    a.getCourseName() != null ? truncate(a.getCourseName(), 20) : "—",
                    a.getAttendanceDate(),
                    a.getStatus()))
                .toList();
            javafx.application.Platform.runLater(() ->
                historyList.setItems(FXCollections.observableArrayList(lines))
            );
        }).start();
    }

    private void showResult(String msg, boolean success) {
        resultLabel.setText(msg);
        resultLabel.setStyle(success
            ? "-fx-text-fill: #38a169; -fx-font-weight: bold; -fx-font-size: 14px;"
            : "-fx-text-fill: #e53e3e; -fx-font-weight: bold; -fx-font-size: 14px;");
        resultLabel.setVisible(true);
    }

    private String formatResult(String raw) {
        return switch (raw.split(":")[0]) {
            case "SUCCESS"        -> "✅ " + raw.substring(8);
            case "ALREADY_MARKED" -> "ℹ️ Already marked present for this session.";
            case "EXPIRED"        -> "⏰ " + raw.substring(8);
            case "INACTIVE"       -> "🚫 Session is no longer active.";
            default               -> "❌ " + raw.substring(raw.indexOf(":") + 1).trim();
        };
    }

    private String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }

    @FXML private void handleBack() { SceneManager.switchTo("student-dashboard"); }
}
