package com.scms.utils;

import javafx.scene.control.TextField;

public class ValidationUtil {

    public static boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && phone.matches("^[0-9+\\-\\s]{7,15}$");
    }

    public static boolean isNumeric(String value) {
        try { Double.parseDouble(value); return true; }
        catch (NumberFormatException e) { return false; }
    }

    public static boolean isInRange(double value, double min, double max) {
        return value >= min && value <= max;
    }

    public static boolean isStrongPassword(String password) {
        return password != null && password.length() >= 8
            && password.matches(".*[A-Z].*")
            && password.matches(".*[0-9].*");
    }

    public static void markRequired(TextField field) {
        field.setStyle("-fx-border-color: #e53e3e;");
    }

    public static void clearMark(TextField field) {
        field.setStyle("");
    }
}
