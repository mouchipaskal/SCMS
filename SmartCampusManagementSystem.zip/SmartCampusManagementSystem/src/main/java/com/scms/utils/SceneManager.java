package com.scms.utils;

import com.scms.models.User;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {

    private static Stage primaryStage;
    private static Scene currentScene;
    private static User currentUser;
    private static boolean darkMode = false;

    public static void setPrimaryStage(Stage stage) { primaryStage = stage; }
    public static Stage getPrimaryStage() { return primaryStage; }

    public static void setCurrentUser(User u) { currentUser = u; }
    public static User getCurrentUser() { return currentUser; }

    public static boolean isDarkMode() { return darkMode; }
    public static void setDarkMode(boolean dm) {
        darkMode = dm;
        applyTheme();
    }

    public static void switchTo(String viewName) {
        try {
            String path = "/com/scms/views/" + viewName + ".fxml";
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(path));
            Parent root = loader.load();
            if (currentScene == null) {
                currentScene = new Scene(root);
                primaryStage.setScene(currentScene);
            } else {
                currentScene.setRoot(root);
            }
            applyTheme();
        } catch (IOException e) {
            System.err.println("[SceneManager] Failed to load: " + viewName + " - " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void applyTheme() {
        if (currentScene == null) return;
        currentScene.getStylesheets().clear();
        currentScene.getStylesheets().add(
            SceneManager.class.getResource("/com/scms/styles/common.css").toExternalForm()
        );
        String theme = darkMode ? "dark-theme.css" : "light-theme.css";
        currentScene.getStylesheets().add(
            SceneManager.class.getResource("/com/scms/styles/" + theme).toExternalForm()
        );
    }
}
