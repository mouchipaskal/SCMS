package com.scms.utils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class QRCodeUtil {

    /**
     * Generate a JavaFX Image of a QR code for the given content.
     * The QR image has a white border and dark modules on a white background.
     */
    public static Image generateQRImage(String content, int size) {
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hints.put(EncodeHintType.MARGIN, 2);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size, hints);

            BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = image.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, size, size);
            g.setColor(new Color(30, 58, 95));  // SCMS dark blue

            for (int x = 0; x < size; x++) {
                for (int y = 0; y < size; y++) {
                    if (matrix.get(x, y)) {
                        g.fillRect(x, y, 1, 1);
                    }
                }
            }
            g.dispose();
            return SwingFXUtils.toFXImage(image, null);
        } catch (WriterException e) {
            System.err.println("[QRCodeUtil] Failed to generate QR: " + e.getMessage());
            return null;
        }
    }

    /**
     * Generate QR code with a label overlay showing the token.
     */
    public static Image generateQRWithLabel(String token, String courseCode, int size) {
        try {
            String content = "SCMS-ATTEND:" + token;
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
            hints.put(EncodeHintType.MARGIN, 2);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size - 60, hints);

            int totalHeight = size + 60;
            BufferedImage image = new BufferedImage(size, totalHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = image.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // White background
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, size, totalHeight);

            // Draw QR modules
            g.setColor(new Color(30, 58, 95));
            for (int x = 0; x < size; x++) {
                for (int y = 0; y < size - 60; y++) {
                    if (matrix.get(x, y)) g.fillRect(x, y, 1, 1);
                }
            }

            // Footer bar
            g.setColor(new Color(30, 58, 95));
            g.fillRect(0, size - 60, size, 60);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Monospaced", Font.BOLD, 22));
            FontMetrics fm = g.getFontMetrics();
            String codeText = "CODE: " + token;
            int textX = (size - fm.stringWidth(codeText)) / 2;
            g.drawString(codeText, textX, size - 32);
            g.setFont(new Font("SansSerif", Font.PLAIN, 13));
            fm = g.getFontMetrics();
            String sub = courseCode + "  •  Valid for limited time";
            g.drawString(sub, (size - fm.stringWidth(sub)) / 2, size - 12);
            g.dispose();

            return SwingFXUtils.toFXImage(image, null);
        } catch (WriterException e) {
            System.err.println("[QRCodeUtil] " + e.getMessage());
            return null;
        }
    }
}
