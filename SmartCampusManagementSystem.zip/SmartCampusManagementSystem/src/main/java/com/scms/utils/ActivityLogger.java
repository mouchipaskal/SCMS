package com.scms.utils;

import com.scms.database.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class ActivityLogger {

    public static void log(int userId, String action, String module) {
        String sql = "INSERT INTO activity_logs (user_id, action, module, created_at) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setString(2, action);
            stmt.setString(3, module);
            stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            stmt.executeUpdate();
        } catch (Exception e) {
            System.err.println("[ActivityLogger] " + e.getMessage());
        }
    }

    public static void log(String action, String module) {
        log(0, action, module);
    }
}
