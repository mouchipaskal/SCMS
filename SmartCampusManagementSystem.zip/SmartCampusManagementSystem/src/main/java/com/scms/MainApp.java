package com.scms;

import com.scms.utils.SceneManager;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        SceneManager.setPrimaryStage(primaryStage);
        primaryStage.setTitle("Smart Campus Management System");
        primaryStage.setMinWidth(1100);
        primaryStage.setMinHeight(720);
        primaryStage.setMaximized(true);
        SceneManager.switchTo("splash");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
