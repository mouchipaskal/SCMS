package com.scms.models;

public class Department {
    private int id;
    private String code, name, headName, description;

    public Department() {}
    public Department(int id, String code, String name) {
        this.id = id; this.code = code; this.name = name;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getHeadName() { return headName; }
    public void setHeadName(String headName) { this.headName = headName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    @Override public String toString() { return name; }
}
