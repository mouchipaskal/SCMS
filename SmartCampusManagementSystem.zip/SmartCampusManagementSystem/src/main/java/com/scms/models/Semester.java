package com.scms.models;

import java.time.LocalDate;

public class Semester {
    private int id;
    private String name, academicYear;
    private LocalDate startDate, endDate;
    private boolean isActive;

    public Semester() {}
    public Semester(int id, String name, String academicYear, boolean isActive) {
        this.id = id; this.name = name; this.academicYear = academicYear; this.isActive = isActive;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    @Override public String toString() { return name + " [" + academicYear + "]"; }
}
