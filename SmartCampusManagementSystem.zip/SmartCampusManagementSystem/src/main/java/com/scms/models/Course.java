package com.scms.models;

public class Course {
    private int id, creditHours, departmentId, semesterId, lecturerId, prerequisiteId, maxStudents;
    private String courseCode, title, description, departmentName, lecturerName, semesterName;
    private boolean isActive;

    public Course() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCreditHours() { return creditHours; }
    public void setCreditHours(int creditHours) { this.creditHours = creditHours; }
    public int getDepartmentId() { return departmentId; }
    public void setDepartmentId(int departmentId) { this.departmentId = departmentId; }
    public int getSemesterId() { return semesterId; }
    public void setSemesterId(int semesterId) { this.semesterId = semesterId; }
    public int getLecturerId() { return lecturerId; }
    public void setLecturerId(int lecturerId) { this.lecturerId = lecturerId; }
    public int getPrerequisiteId() { return prerequisiteId; }
    public void setPrerequisiteId(int prerequisiteId) { this.prerequisiteId = prerequisiteId; }
    public int getMaxStudents() { return maxStudents; }
    public void setMaxStudents(int maxStudents) { this.maxStudents = maxStudents; }
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
    public String getLecturerName() { return lecturerName; }
    public void setLecturerName(String lecturerName) { this.lecturerName = lecturerName; }
    public String getSemesterName() { return semesterName; }
    public void setSemesterName(String semesterName) { this.semesterName = semesterName; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    @Override public String toString() { return courseCode + " - " + title; }
}
