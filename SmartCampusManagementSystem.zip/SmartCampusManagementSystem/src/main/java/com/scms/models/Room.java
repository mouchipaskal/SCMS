package com.scms.models;

public class Room {
    private int id, capacity;
    private String roomNumber, building, roomType;

    public Room() {}
    public Room(int id, String roomNumber, String building, int capacity, String roomType) {
        this.id = id; this.roomNumber = roomNumber; this.building = building;
        this.capacity = capacity; this.roomType = roomType;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public String getBuilding() { return building; }
    public void setBuilding(String building) { this.building = building; }
    public String getRoomType() { return roomType; }
    public void setRoomType(String roomType) { this.roomType = roomType; }
    @Override public String toString() { return roomNumber + " - " + building + " (Cap: " + capacity + ")"; }
}
