package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Attendance;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AttendanceService {

    public List<Attendance> getByCourse(int courseId, LocalDate date) {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT a.*, s.full_name AS student_name, c.title AS course_name " +
                     "FROM attendance a JOIN students s ON a.student_id=s.id JOIN courses c ON a.course_id=c.id " +
                     "WHERE a.course_id=? AND a.attendance_date=? ORDER BY s.full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, courseId); st.setDate(2, Date.valueOf(date));
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Attendance> getByStudent(int studentId) {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT a.*, s.full_name AS student_name, c.title AS course_name " +
                     "FROM attendance a JOIN students s ON a.student_id=s.id JOIN courses c ON a.course_id=c.id " +
                     "WHERE a.student_id=? ORDER BY a.attendance_date DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public double getAttendancePercentage(int studentId, int courseId) {
        String sql = "SELECT " +
                     "COUNT(*) AS total, " +
                     "SUM(CASE WHEN status='Present' OR status='Late' THEN 1 ELSE 0 END) AS present " +
                     "FROM attendance WHERE student_id=? AND course_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId); st.setInt(2, courseId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                int total = rs.getInt("total");
                int present = rs.getInt("present");
                if (total == 0) return 0;
                return (present * 100.0) / total;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public boolean markAttendance(Attendance a) {
        String sql = "INSERT INTO attendance (student_id, course_id, attendance_date, status, marked_by, notes) " +
                     "VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE status=?, notes=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, a.getStudentId()); st.setInt(2, a.getCourseId());
            st.setDate(3, Date.valueOf(a.getAttendanceDate())); st.setString(4, a.getStatus());
            if (a.getMarkedBy() > 0) st.setInt(5, a.getMarkedBy()); else st.setNull(5, Types.INTEGER);
            st.setString(6, a.getNotes());
            st.setString(7, a.getStatus()); st.setString(8, a.getNotes());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private Attendance mapRow(ResultSet rs) throws SQLException {
        Attendance a = new Attendance();
        a.setId(rs.getInt("id")); a.setStudentId(rs.getInt("student_id"));
        a.setCourseId(rs.getInt("course_id")); a.setStatus(rs.getString("status"));
        a.setNotes(rs.getString("notes")); a.setStudentName(rs.getString("student_name"));
        a.setCourseName(rs.getString("course_name")); a.setMarkedBy(rs.getInt("marked_by"));
        Date d = rs.getDate("attendance_date");
        if (d != null) a.setAttendanceDate(d.toLocalDate());
        return a;
    }
}
