package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.User;
import com.scms.utils.BCryptUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class UserService {

    public User login(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ? AND is_active = TRUE";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, username);
            ResultSet rs = s.executeQuery();
            if (rs.next()) {
                String hash = rs.getString("password_hash");
                if (BCryptUtil.verify(password, hash)) {
                    User u = mapRow(rs);
                    updateLastLogin(u.getId());
                    return u;
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean createUser(User u) {
        String sql = "INSERT INTO users (username, password_hash, email, full_name, role, phone) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            s.setString(1, u.getUsername());
            s.setString(2, u.getPasswordHash());
            s.setString(3, u.getEmail());
            s.setString(4, u.getFullName());
            s.setString(5, u.getRole());
            s.setString(6, u.getPhone());
            int rows = s.executeUpdate();
            if (rows > 0) {
                try (ResultSet keys = s.getGeneratedKeys()) {
                    if (keys.next()) {
                        u.setId(keys.getInt(1));
                        return true;
                    }
                }
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean updateUser(User u) {
        String sql = "UPDATE users SET email=?, full_name=?, phone=?, is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, u.getEmail());
            s.setString(2, u.getFullName());
            s.setString(3, u.getPhone());
            s.setBoolean(4, u.isActive());
            s.setInt(5, u.getId());
            return s.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean changePassword(int userId, String newPassword) {
        String sql = "UPDATE users SET password_hash=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, BCryptUtil.hash(newPassword));
            s.setInt(2, userId);
            return s.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean toggleActive(int userId, boolean active) {
        String sql = "UPDATE users SET is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setBoolean(1, active);
            s.setInt(2, userId);
            return s.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean usernameExists(String username) {
        String sql = "SELECT id FROM users WHERE username=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, username);
            return s.executeQuery().next();
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int getLastInsertedId() {
        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT LAST_INSERT_ID()")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return -1;
    }

    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY full_name";
        try (Connection c = DBConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    private void updateLastLogin(int userId) {
        String sql = "UPDATE users SET last_login=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement s = c.prepareStatement(sql)) {
            s.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            s.setInt(2, userId);
            s.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setEmail(rs.getString("email"));
        u.setFullName(rs.getString("full_name"));
        u.setRole(rs.getString("role"));
        u.setActive(rs.getBoolean("is_active"));
        u.setPhone(rs.getString("phone"));
        u.setProfilePhoto(rs.getString("profile_photo"));
        Timestamp ll = rs.getTimestamp("last_login");
        if (ll != null) u.setLastLogin(ll.toLocalDateTime());
        return u;
    }
}
