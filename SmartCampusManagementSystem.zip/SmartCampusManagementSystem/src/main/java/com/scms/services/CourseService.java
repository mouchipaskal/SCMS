package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseService {

    private static final String BASE_SQL =
        "SELECT co.*, d.name AS dept_name, l.full_name AS lecturer_name, se.name AS semester_name " +
        "FROM courses co " +
        "LEFT JOIN departments d ON co.department_id=d.id " +
        "LEFT JOIN lecturers l ON co.lecturer_id=l.id " +
        "LEFT JOIN semesters se ON co.semester_id=se.id ";

    public List<Course> getAll() {
        List<Course> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(BASE_SQL + "ORDER BY co.course_code")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Course> search(String keyword) {
        List<Course> list = new ArrayList<>();
        String sql = BASE_SQL + "WHERE co.course_code LIKE ? OR co.title LIKE ? ORDER BY co.course_code";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            st.setString(1, kw); st.setString(2, kw);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Course> getByLecturer(int lecturerId) {
        List<Course> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE co.lecturer_id=? ORDER BY co.course_code")) {
            st.setInt(1, lecturerId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Course> getBySemester(int semesterId) {
        List<Course> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE co.semester_id=? AND co.is_active=TRUE ORDER BY co.course_code")) {
            st.setInt(1, semesterId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Course getById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE co.id=?")) {
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean add(Course co) {
        String sql = "INSERT INTO courses (course_code, title, credit_hours, department_id, semester_id, lecturer_id, description, max_students) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, co.getCourseCode()); st.setString(2, co.getTitle());
            st.setInt(3, co.getCreditHours());
            if (co.getDepartmentId() > 0) st.setInt(4, co.getDepartmentId()); else st.setNull(4, Types.INTEGER);
            if (co.getSemesterId() > 0) st.setInt(5, co.getSemesterId()); else st.setNull(5, Types.INTEGER);
            if (co.getLecturerId() > 0) st.setInt(6, co.getLecturerId()); else st.setNull(6, Types.INTEGER);
            st.setString(7, co.getDescription());
            st.setInt(8, co.getMaxStudents() > 0 ? co.getMaxStudents() : 50);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Course co) {
        String sql = "UPDATE courses SET course_code=?, title=?, credit_hours=?, department_id=?, semester_id=?, lecturer_id=?, description=?, max_students=?, is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, co.getCourseCode()); st.setString(2, co.getTitle());
            st.setInt(3, co.getCreditHours());
            if (co.getDepartmentId() > 0) st.setInt(4, co.getDepartmentId()); else st.setNull(4, Types.INTEGER);
            if (co.getSemesterId() > 0) st.setInt(5, co.getSemesterId()); else st.setNull(5, Types.INTEGER);
            if (co.getLecturerId() > 0) st.setInt(6, co.getLecturerId()); else st.setNull(6, Types.INTEGER);
            st.setString(7, co.getDescription()); st.setInt(8, co.getMaxStudents());
            st.setBoolean(9, co.isActive()); st.setInt(10, co.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("DELETE FROM courses WHERE id=?")) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int countAll() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM courses WHERE is_active=TRUE")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Course mapRow(ResultSet rs) throws SQLException {
        Course co = new Course();
        co.setId(rs.getInt("id")); co.setCourseCode(rs.getString("course_code"));
        co.setTitle(rs.getString("title")); co.setCreditHours(rs.getInt("credit_hours"));
        co.setDepartmentId(rs.getInt("department_id")); co.setDepartmentName(rs.getString("dept_name"));
        co.setSemesterId(rs.getInt("semester_id")); co.setSemesterName(rs.getString("semester_name"));
        co.setLecturerId(rs.getInt("lecturer_id")); co.setLecturerName(rs.getString("lecturer_name"));
        co.setDescription(rs.getString("description")); co.setMaxStudents(rs.getInt("max_students"));
        co.setActive(rs.getBoolean("is_active"));
        return co;
    }
}
