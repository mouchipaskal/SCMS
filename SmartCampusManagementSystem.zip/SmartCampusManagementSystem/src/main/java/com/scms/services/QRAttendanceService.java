package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Attendance;
import com.scms.models.QRSession;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class QRAttendanceService {

    /**
     * Create a new QR session for a course. Deactivates any previous active
     * session for the same course on the same date.
     */
    public QRSession createSession(int courseId, int createdByLecturerId, LocalDate date, int durationMinutes) {
        // Deactivate existing sessions for this course today
        deactivateExistingSessions(courseId, date);

        String token = UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
        LocalDateTime expiresAt = LocalDateTime.now().plusMinutes(durationMinutes);

        String sql = "INSERT INTO qr_sessions (token, course_id, session_date, expires_at, is_active, created_by) VALUES (?,?,?,?,TRUE,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            st.setString(1, token);
            st.setInt(2, courseId);
            st.setDate(3, Date.valueOf(date));
            st.setTimestamp(4, Timestamp.valueOf(expiresAt));
            if (createdByLecturerId > 0) st.setInt(5, createdByLecturerId); else st.setNull(5, Types.INTEGER);
            st.executeUpdate();
            ResultSet keys = st.getGeneratedKeys();
            if (keys.next()) {
                QRSession session = new QRSession();
                session.setId(keys.getInt(1));
                session.setToken(token);
                session.setCourseId(courseId);
                session.setSessionDate(date);
                session.setExpiresAt(expiresAt);
                session.setCreatedBy(createdByLecturerId);
                session.setActive(true);
                return session;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    private void deactivateExistingSessions(int courseId, LocalDate date) {
        String sql = "UPDATE qr_sessions SET is_active=FALSE WHERE course_id=? AND session_date=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, courseId);
            st.setDate(2, Date.valueOf(date));
            st.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Validate a QR token and mark the student present.
     * Returns a result message.
     */
    public String submitQRAttendance(String token, int studentId) {
        QRSession session = getActiveSession(token);
        if (session == null) return "INVALID: QR code not found or session has expired.";
        if (session.isExpired()) {
            deactivateSession(session.getId());
            return "EXPIRED: This QR code has expired. Ask your lecturer to regenerate.";
        }
        if (!session.isActive()) return "INACTIVE: This QR session is no longer active.";

        // Check if already marked
        if (alreadyMarked(studentId, session.getCourseId(), session.getSessionDate())) {
            return "ALREADY_MARKED: Attendance already recorded for this session.";
        }

        // Mark as Present
        Attendance a = new Attendance();
        a.setStudentId(studentId);
        a.setCourseId(session.getCourseId());
        a.setAttendanceDate(session.getSessionDate());
        a.setStatus("Present");
        a.setNotes("Marked via QR code");

        AttendanceService attendanceService = new AttendanceService();
        if (attendanceService.markAttendance(a)) {
            return "SUCCESS: Attendance marked as Present for " + session.getSessionDate();
        }
        return "ERROR: Could not save attendance. Try again.";
    }

    private boolean alreadyMarked(int studentId, int courseId, LocalDate date) {
        String sql = "SELECT id FROM attendance WHERE student_id=? AND course_id=? AND attendance_date=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId); st.setInt(2, courseId); st.setDate(3, Date.valueOf(date));
            return st.executeQuery().next();
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private QRSession getActiveSession(String token) {
        String sql = "SELECT q.*, c.course_code, c.title AS course_title " +
                     "FROM qr_sessions q JOIN courses c ON q.course_id=c.id " +
                     "WHERE q.token=? AND q.is_active=TRUE";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, token.trim().toUpperCase());
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public void deactivateSession(int sessionId) {
        String sql = "UPDATE qr_sessions SET is_active=FALSE WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, sessionId);
            st.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /** How many students have scanned this session so far */
    public int countScanned(int sessionId) {
        // Scanned students are in attendance table marked via QR on that course+date
        String sql = "SELECT COUNT(*) FROM attendance a " +
                     "JOIN qr_sessions q ON a.course_id=q.course_id AND a.attendance_date=q.session_date " +
                     "WHERE q.id=? AND a.notes LIKE 'Marked via QR%'";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, sessionId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    /** Students who have already scanned for this session */
    public List<String> getScannedStudents(int sessionId) {
        List<String> names = new ArrayList<>();
        String sql = "SELECT s.full_name, a.created_at " +
                     "FROM attendance a " +
                     "JOIN students s ON a.student_id=s.id " +
                     "JOIN qr_sessions q ON a.course_id=q.course_id AND a.attendance_date=q.session_date " +
                     "WHERE q.id=? AND a.notes LIKE 'Marked via QR%' ORDER BY a.created_at DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, sessionId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String time = rs.getTimestamp("created_at").toLocalDateTime()
                                .toString().replace("T", " ").substring(0, 16);
                names.add(rs.getString("full_name") + "  (" + time + ")");
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return names;
    }

    /** Get active QR sessions for a course (for student lookup) */
    public QRSession getActiveSessionForCourse(int courseId, LocalDate date) {
        String sql = "SELECT q.*, c.course_code, c.title AS course_title " +
                     "FROM qr_sessions q JOIN courses c ON q.course_id=c.id " +
                     "WHERE q.course_id=? AND q.session_date=? AND q.is_active=TRUE AND q.expires_at > NOW()";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, courseId);
            st.setDate(2, Date.valueOf(date));
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    private QRSession mapRow(ResultSet rs) throws SQLException {
        QRSession s = new QRSession();
        s.setId(rs.getInt("id"));
        s.setToken(rs.getString("token"));
        s.setCourseId(rs.getInt("course_id"));
        s.setCourseCode(rs.getString("course_code"));
        s.setCourseTitle(rs.getString("course_title"));
        s.setActive(rs.getBoolean("is_active"));
        Date sd = rs.getDate("session_date");
        if (sd != null) s.setSessionDate(sd.toLocalDate());
        Timestamp exp = rs.getTimestamp("expires_at");
        if (exp != null) s.setExpiresAt(exp.toLocalDateTime());
        Timestamp ca = rs.getTimestamp("created_at");
        if (ca != null) s.setCreatedAt(ca.toLocalDateTime());
        return s;
    }
}
