package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Registration;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationService {

    public List<Registration> getByStudent(int studentId) {
        List<Registration> list = new ArrayList<>();
        String sql = "SELECT r.*, c.title AS course_title, c.course_code, se.name AS semester_name, st.full_name AS student_name " +
                     "FROM registrations r " +
                     "JOIN courses c ON r.course_id=c.id " +
                     "LEFT JOIN semesters se ON r.semester_id=se.id " +
                     "LEFT JOIN students st ON r.student_id=st.id " +
                     "WHERE r.student_id=? ORDER BY r.registration_date DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Registration> getByCourse(int courseId) {
        List<Registration> list = new ArrayList<>();
        String sql = "SELECT r.*, c.title AS course_title, c.course_code, se.name AS semester_name, st.full_name AS student_name " +
                     "FROM registrations r " +
                     "JOIN courses c ON r.course_id=c.id " +
                     "LEFT JOIN semesters se ON r.semester_id=se.id " +
                     "JOIN students st ON r.student_id=st.id " +
                     "WHERE r.course_id=? AND r.status='Active' ORDER BY st.full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, courseId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Registration> getAll() {
        List<Registration> list = new ArrayList<>();
        String sql = "SELECT r.*, c.title AS course_title, c.course_code, se.name AS semester_name, st.full_name AS student_name " +
                     "FROM registrations r " +
                     "JOIN courses c ON r.course_id=c.id " +
                     "LEFT JOIN semesters se ON r.semester_id=se.id " +
                     "JOIN students st ON r.student_id=st.id ORDER BY r.registration_date DESC";
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean alreadyRegistered(int studentId, int courseId) {
        String sql = "SELECT id FROM registrations WHERE student_id=? AND course_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId); st.setInt(2, courseId);
            return st.executeQuery().next();
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int getTotalCreditHours(int studentId, int semesterId) {
        String sql = "SELECT SUM(c.credit_hours) FROM registrations r JOIN courses c ON r.course_id=c.id " +
                     "WHERE r.student_id=? AND r.semester_id=? AND r.status='Active'";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId); st.setInt(2, semesterId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public boolean register(Registration r) {
        String sql = "INSERT INTO registrations (student_id, course_id, semester_id, status) VALUES (?,?,?,'Active')";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, r.getStudentId()); st.setInt(2, r.getCourseId());
            if (r.getSemesterId() > 0) st.setInt(3, r.getSemesterId()); else st.setNull(3, Types.INTEGER);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean drop(int registrationId) {
        String sql = "UPDATE registrations SET status='Dropped' WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, registrationId);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int countAll() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM registrations WHERE status='Active'")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Registration mapRow(ResultSet rs) throws SQLException {
        Registration r = new Registration();
        r.setId(rs.getInt("id")); r.setStudentId(rs.getInt("student_id"));
        r.setCourseId(rs.getInt("course_id")); r.setSemesterId(rs.getInt("semester_id"));
        r.setStatus(rs.getString("status"));
        r.setCourseTitle(rs.getString("course_title")); r.setCourseCode(rs.getString("course_code"));
        r.setSemesterName(rs.getString("semester_name")); r.setStudentName(rs.getString("student_name"));
        Timestamp rd = rs.getTimestamp("registration_date");
        if (rd != null) r.setRegistrationDate(rd.toLocalDateTime());
        return r;
    }
}
