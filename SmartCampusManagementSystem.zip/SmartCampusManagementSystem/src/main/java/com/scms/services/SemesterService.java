package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Semester;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SemesterService {

    public List<Semester> getAll() {
        List<Semester> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM semesters ORDER BY academic_year DESC, name")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Semester getActive() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM semesters WHERE is_active=TRUE LIMIT 1")) {
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public Semester getById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT * FROM semesters WHERE id=?")) {
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean add(Semester s) {
        String sql = "INSERT INTO semesters (name, academic_year, start_date, end_date, is_active) VALUES (?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, s.getName()); st.setString(2, s.getAcademicYear());
            if (s.getStartDate() != null) st.setDate(3, Date.valueOf(s.getStartDate())); else st.setNull(3, Types.DATE);
            if (s.getEndDate() != null) st.setDate(4, Date.valueOf(s.getEndDate())); else st.setNull(4, Types.DATE);
            st.setBoolean(5, s.isActive());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Semester s) {
        String sql = "UPDATE semesters SET name=?, academic_year=?, start_date=?, end_date=?, is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, s.getName()); st.setString(2, s.getAcademicYear());
            if (s.getStartDate() != null) st.setDate(3, Date.valueOf(s.getStartDate())); else st.setNull(3, Types.DATE);
            if (s.getEndDate() != null) st.setDate(4, Date.valueOf(s.getEndDate())); else st.setNull(4, Types.DATE);
            st.setBoolean(5, s.isActive()); st.setInt(6, s.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("DELETE FROM semesters WHERE id=?")) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private Semester mapRow(ResultSet rs) throws SQLException {
        Semester s = new Semester();
        s.setId(rs.getInt("id")); s.setName(rs.getString("name"));
        s.setAcademicYear(rs.getString("academic_year"));
        s.setActive(rs.getBoolean("is_active"));
        Date sd = rs.getDate("start_date");
        Date ed = rs.getDate("end_date");
        if (sd != null) s.setStartDate(sd.toLocalDate());
        if (ed != null) s.setEndDate(ed.toLocalDate());
        return s;
    }
}
