package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Lecturer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LecturerService {

    private static final String BASE_SQL =
        "SELECT l.*, d.name AS dept_name FROM lecturers l LEFT JOIN departments d ON l.department_id=d.id ";

    public List<Lecturer> getAll() {
        List<Lecturer> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(BASE_SQL + "ORDER BY l.full_name")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Lecturer> search(String keyword) {
        List<Lecturer> list = new ArrayList<>();
        String sql = BASE_SQL + "WHERE l.full_name LIKE ? OR l.staff_id LIKE ? OR l.specialization LIKE ? ORDER BY l.full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            st.setString(1, kw); st.setString(2, kw); st.setString(3, kw);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Lecturer getById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE l.id=?")) {
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public Lecturer getByUserId(int userId) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE l.user_id=?")) {
            st.setInt(1, userId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean add(Lecturer l) {
        String sql = "INSERT INTO lecturers (user_id, staff_id, full_name, email, phone, department_id, specialization, office_location) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            if (l.getUserId() > 0) st.setInt(1, l.getUserId()); else st.setNull(1, Types.INTEGER);
            st.setString(2, l.getStaffId());
            st.setString(3, l.getFullName());
            st.setString(4, l.getEmail());
            st.setString(5, l.getPhone());
            if (l.getDepartmentId() > 0) st.setInt(6, l.getDepartmentId()); else st.setNull(6, Types.INTEGER);
            st.setString(7, l.getSpecialization());
            st.setString(8, l.getOfficeLocation());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Lecturer l) {
        String sql = "UPDATE lecturers SET full_name=?, email=?, phone=?, department_id=?, specialization=?, office_location=?, is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, l.getFullName());
            st.setString(2, l.getEmail());
            st.setString(3, l.getPhone());
            if (l.getDepartmentId() > 0) st.setInt(4, l.getDepartmentId()); else st.setNull(4, Types.INTEGER);
            st.setString(5, l.getSpecialization());
            st.setString(6, l.getOfficeLocation());
            st.setBoolean(7, l.isActive());
            st.setInt(8, l.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM lecturers WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int countAll() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM lecturers WHERE is_active=TRUE")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Lecturer mapRow(ResultSet rs) throws SQLException {
        Lecturer l = new Lecturer();
        l.setId(rs.getInt("id"));
        l.setUserId(rs.getInt("user_id"));
        l.setStaffId(rs.getString("staff_id"));
        l.setFullName(rs.getString("full_name"));
        l.setEmail(rs.getString("email"));
        l.setPhone(rs.getString("phone"));
        l.setDepartmentId(rs.getInt("department_id"));
        l.setDepartmentName(rs.getString("dept_name"));
        l.setSpecialization(rs.getString("specialization"));
        l.setOfficeLocation(rs.getString("office_location"));
        l.setActive(rs.getBoolean("is_active"));
        return l;
    }
}
