package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Room;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoomService {

    public List<Room> getAll() {
        List<Room> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM rooms ORDER BY room_number")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean add(Room r) {
        String sql = "INSERT INTO rooms (room_number, building, capacity, room_type) VALUES (?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, r.getRoomNumber()); st.setString(2, r.getBuilding());
            st.setInt(3, r.getCapacity()); st.setString(4, r.getRoomType());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Room r) {
        String sql = "UPDATE rooms SET room_number=?, building=?, capacity=?, room_type=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, r.getRoomNumber()); st.setString(2, r.getBuilding());
            st.setInt(3, r.getCapacity()); st.setString(4, r.getRoomType()); st.setInt(5, r.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("DELETE FROM rooms WHERE id=?")) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private Room mapRow(ResultSet rs) throws SQLException {
        return new Room(rs.getInt("id"), rs.getString("room_number"),
                        rs.getString("building"), rs.getInt("capacity"), rs.getString("room_type"));
    }
}
