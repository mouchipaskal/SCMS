package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentService {

    public List<Student> getAll() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, d.name AS dept_name FROM students s LEFT JOIN departments d ON s.department_id=d.id ORDER BY s.full_name";
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Student> search(String keyword) {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, d.name AS dept_name FROM students s LEFT JOIN departments d ON s.department_id=d.id " +
                     "WHERE s.full_name LIKE ? OR s.student_number LIKE ? OR s.email LIKE ? ORDER BY s.full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            st.setString(1, kw); st.setString(2, kw); st.setString(3, kw);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Student getById(int id) {
        String sql = "SELECT s.*, d.name AS dept_name FROM students s LEFT JOIN departments d ON s.department_id=d.id WHERE s.id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public Student getByUserId(int userId) {
        String sql = "SELECT s.*, d.name AS dept_name FROM students s LEFT JOIN departments d ON s.department_id=d.id WHERE s.user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, userId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean add(Student s) {
        String sql = "INSERT INTO students (user_id, student_number, full_name, gender, date_of_birth, email, phone, address, department_id, admission_year) " +
                     "VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            if (s.getUserId() > 0) st.setInt(1, s.getUserId()); else st.setNull(1, Types.INTEGER);
            st.setString(2, s.getStudentNumber());
            st.setString(3, s.getFullName());
            st.setString(4, s.getGender());
            if (s.getDateOfBirth() != null) st.setDate(5, Date.valueOf(s.getDateOfBirth())); else st.setNull(5, Types.DATE);
            st.setString(6, s.getEmail());
            st.setString(7, s.getPhone());
            st.setString(8, s.getAddress());
            if (s.getDepartmentId() > 0) st.setInt(9, s.getDepartmentId()); else st.setNull(9, Types.INTEGER);
            st.setInt(10, s.getAdmissionYear());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Student s) {
        String sql = "UPDATE students SET full_name=?, gender=?, date_of_birth=?, email=?, phone=?, address=?, department_id=?, admission_year=?, is_active=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, s.getFullName());
            st.setString(2, s.getGender());
            if (s.getDateOfBirth() != null) st.setDate(3, Date.valueOf(s.getDateOfBirth())); else st.setNull(3, Types.DATE);
            st.setString(4, s.getEmail());
            st.setString(5, s.getPhone());
            st.setString(6, s.getAddress());
            if (s.getDepartmentId() > 0) st.setInt(7, s.getDepartmentId()); else st.setNull(7, Types.INTEGER);
            st.setInt(8, s.getAdmissionYear());
            st.setBoolean(9, s.isActive());
            st.setInt(10, s.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM students WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int countAll() {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM students WHERE is_active=TRUE")) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        Student s = new Student();
        s.setId(rs.getInt("id"));
        s.setUserId(rs.getInt("user_id"));
        s.setStudentNumber(rs.getString("student_number"));
        s.setFullName(rs.getString("full_name"));
        s.setGender(rs.getString("gender"));
        s.setEmail(rs.getString("email"));
        s.setPhone(rs.getString("phone"));
        s.setAddress(rs.getString("address"));
        s.setDepartmentId(rs.getInt("department_id"));
        s.setDepartmentName(rs.getString("dept_name"));
        s.setAdmissionYear(rs.getInt("admission_year"));
        s.setActive(rs.getBoolean("is_active"));
        s.setPhotoPath(rs.getString("photo_path"));
        Date dob = rs.getDate("date_of_birth");
        if (dob != null) s.setDateOfBirth(dob.toLocalDate());
        return s;
    }
}
