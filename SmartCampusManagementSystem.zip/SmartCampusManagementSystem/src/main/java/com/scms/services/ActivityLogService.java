package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.ActivityLog;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ActivityLogService {

    public List<ActivityLog> getAll(int limit) {
        List<ActivityLog> list = new ArrayList<>();
        String sql = "SELECT al.*, u.username FROM activity_logs al LEFT JOIN users u ON al.user_id=u.id " +
                     "ORDER BY al.created_at DESC LIMIT ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, limit);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                ActivityLog log = new ActivityLog();
                log.setId(rs.getInt("id")); log.setUserId(rs.getInt("user_id"));
                log.setAction(rs.getString("action")); log.setModule(rs.getString("module"));
                log.setUsername(rs.getString("username"));
                Timestamp ts = rs.getTimestamp("created_at");
                if (ts != null) log.setCreatedAt(ts.toLocalDateTime());
                list.add(log);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}
