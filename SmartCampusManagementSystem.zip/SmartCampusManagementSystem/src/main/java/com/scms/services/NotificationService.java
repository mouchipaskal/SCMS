package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Notification;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationService {

    public List<Notification> getByUser(int userId) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, userId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public int countUnread(int userId) {
        String sql = "SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=FALSE";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, userId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public void send(int userId, String title, String message, String type) {
        String sql = "INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            if (userId > 0) st.setInt(1, userId); else st.setNull(1, Types.INTEGER);
            st.setString(2, title); st.setString(3, message); st.setString(4, type);
            st.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void broadcast(String title, String message, String type) {
        String sql = "INSERT INTO notifications (user_id, title, message, type) SELECT id, ?, ?, ? FROM users WHERE is_active=TRUE";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, title); st.setString(2, message); st.setString(3, type);
            st.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public boolean markRead(int id) {
        String sql = "UPDATE notifications SET is_read=TRUE WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public void markAllRead(int userId) {
        String sql = "UPDATE notifications SET is_read=TRUE WHERE user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, userId);
            st.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private Notification mapRow(ResultSet rs) throws SQLException {
        Notification n = new Notification();
        n.setId(rs.getInt("id")); n.setUserId(rs.getInt("user_id"));
        n.setTitle(rs.getString("title")); n.setMessage(rs.getString("message"));
        n.setType(rs.getString("type")); n.setRead(rs.getBoolean("is_read"));
        Timestamp ts = rs.getTimestamp("created_at");
        if (ts != null) n.setCreatedAt(ts.toLocalDateTime());
        return n;
    }
}
