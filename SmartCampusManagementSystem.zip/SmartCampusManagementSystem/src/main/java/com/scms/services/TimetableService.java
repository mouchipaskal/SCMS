package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Timetable;

import java.sql.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class TimetableService {

    private static final String BASE_SQL =
        "SELECT t.*, c.course_code, c.title AS course_title, r.room_number, l.full_name AS lecturer_name, se.name AS semester_name " +
        "FROM timetable t " +
        "LEFT JOIN courses c ON t.course_id=c.id " +
        "LEFT JOIN rooms r ON t.room_id=r.id " +
        "LEFT JOIN lecturers l ON c.lecturer_id=l.id " +
        "LEFT JOIN semesters se ON t.semester_id=se.id ";

    public List<Timetable> getAll() {
        List<Timetable> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(BASE_SQL + "ORDER BY FIELD(t.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), t.start_time")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Timetable> getBySemester(int semesterId) {
        List<Timetable> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(BASE_SQL + "WHERE t.semester_id=? ORDER BY FIELD(t.day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), t.start_time")) {
            st.setInt(1, semesterId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean hasConflict(int lecturerId, int roomId, String day, LocalTime start, LocalTime end, int excludeId) {
        String sql = "SELECT t.id FROM timetable t JOIN courses c ON t.course_id=c.id " +
                     "WHERE t.day_of_week=? AND t.id!=? " +
                     "AND (c.lecturer_id=? OR t.room_id=?) " +
                     "AND NOT (? >= t.end_time OR ? <= t.start_time)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, day); st.setInt(2, excludeId);
            st.setInt(3, lecturerId); st.setInt(4, roomId);
            st.setTime(5, Time.valueOf(end)); st.setTime(6, Time.valueOf(start));
            return st.executeQuery().next();
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean add(Timetable t) {
        String sql = "INSERT INTO timetable (course_id, room_id, semester_id, day_of_week, start_time, end_time) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, t.getCourseId());
            if (t.getRoomId() > 0) st.setInt(2, t.getRoomId()); else st.setNull(2, Types.INTEGER);
            if (t.getSemesterId() > 0) st.setInt(3, t.getSemesterId()); else st.setNull(3, Types.INTEGER);
            st.setString(4, t.getDayOfWeek());
            st.setTime(5, Time.valueOf(t.getStartTime())); st.setTime(6, Time.valueOf(t.getEndTime()));
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Timetable t) {
        String sql = "UPDATE timetable SET course_id=?, room_id=?, semester_id=?, day_of_week=?, start_time=?, end_time=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, t.getCourseId());
            if (t.getRoomId() > 0) st.setInt(2, t.getRoomId()); else st.setNull(2, Types.INTEGER);
            if (t.getSemesterId() > 0) st.setInt(3, t.getSemesterId()); else st.setNull(3, Types.INTEGER);
            st.setString(4, t.getDayOfWeek());
            st.setTime(5, Time.valueOf(t.getStartTime())); st.setTime(6, Time.valueOf(t.getEndTime()));
            st.setInt(7, t.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("DELETE FROM timetable WHERE id=?")) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private Timetable mapRow(ResultSet rs) throws SQLException {
        Timetable t = new Timetable();
        t.setId(rs.getInt("id")); t.setCourseId(rs.getInt("course_id"));
        t.setRoomId(rs.getInt("room_id")); t.setSemesterId(rs.getInt("semester_id"));
        t.setDayOfWeek(rs.getString("day_of_week")); t.setCourseCode(rs.getString("course_code"));
        t.setCourseTitle(rs.getString("course_title")); t.setRoomNumber(rs.getString("room_number"));
        t.setLecturerName(rs.getString("lecturer_name")); t.setSemesterName(rs.getString("semester_name"));
        Time st = rs.getTime("start_time"); Time et = rs.getTime("end_time");
        if (st != null) t.setStartTime(st.toLocalTime());
        if (et != null) t.setEndTime(et.toLocalTime());
        return t;
    }
}
