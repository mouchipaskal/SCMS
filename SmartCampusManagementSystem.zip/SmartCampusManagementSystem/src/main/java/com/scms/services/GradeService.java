package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Grade;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GradeService {

    public List<Grade> getByStudent(int studentId) {
        List<Grade> list = new ArrayList<>();
        String sql = "SELECT g.*, s.full_name AS student_name, c.course_code, c.title AS course_title, se.name AS semester_name " +
                     "FROM grades g JOIN students s ON g.student_id=s.id JOIN courses c ON g.course_id=c.id " +
                     "LEFT JOIN semesters se ON g.semester_id=se.id WHERE g.student_id=? ORDER BY se.name, c.course_code";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<Grade> getByCourse(int courseId) {
        List<Grade> list = new ArrayList<>();
        String sql = "SELECT g.*, s.full_name AS student_name, c.course_code, c.title AS course_title, se.name AS semester_name " +
                     "FROM grades g JOIN students s ON g.student_id=s.id JOIN courses c ON g.course_id=c.id " +
                     "LEFT JOIN semesters se ON g.semester_id=se.id WHERE g.course_id=? ORDER BY s.full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, courseId);
            ResultSet rs = st.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean saveGrade(Grade g) {
        String gradeLetter = Grade.computeGrade(g.getCaScore() + g.getExamScore());
        double gradePoints = Grade.gradeToPoints(gradeLetter);
        String sql = "INSERT INTO grades (student_id, course_id, semester_id, ca_score, exam_score, grade_letter, grade_points, remarks) " +
                     "VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE ca_score=?, exam_score=?, grade_letter=?, grade_points=?, remarks=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, g.getStudentId()); st.setInt(2, g.getCourseId());
            if (g.getSemesterId() > 0) st.setInt(3, g.getSemesterId()); else st.setNull(3, Types.INTEGER);
            st.setDouble(4, g.getCaScore()); st.setDouble(5, g.getExamScore());
            st.setString(6, gradeLetter); st.setDouble(7, gradePoints);
            st.setString(8, g.getRemarks());
            st.setDouble(9, g.getCaScore()); st.setDouble(10, g.getExamScore());
            st.setString(11, gradeLetter); st.setDouble(12, gradePoints);
            st.setString(13, g.getRemarks());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public double calculateGPA(int studentId, int semesterId) {
        String sql = "SELECT SUM(g.grade_points * c.credit_hours) / SUM(c.credit_hours) AS gpa " +
                     "FROM grades g JOIN courses c ON g.course_id=c.id " +
                     "WHERE g.student_id=? AND g.semester_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId); st.setInt(2, semesterId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return rs.getDouble("gpa");
        } catch (SQLException e) { e.printStackTrace(); }
        return 0.0;
    }

    public double calculateCGPA(int studentId) {
        String sql = "SELECT SUM(g.grade_points * c.credit_hours) / SUM(c.credit_hours) AS cgpa " +
                     "FROM grades g JOIN courses c ON g.course_id=c.id WHERE g.student_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setInt(1, studentId);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return rs.getDouble("cgpa");
        } catch (SQLException e) { e.printStackTrace(); }
        return 0.0;
    }

    private Grade mapRow(ResultSet rs) throws SQLException {
        Grade g = new Grade();
        g.setId(rs.getInt("id")); g.setStudentId(rs.getInt("student_id"));
        g.setCourseId(rs.getInt("course_id")); g.setSemesterId(rs.getInt("semester_id"));
        g.setCaScore(rs.getDouble("ca_score")); g.setExamScore(rs.getDouble("exam_score"));
        g.setTotalScore(rs.getDouble("total_score")); g.setGradeLetter(rs.getString("grade_letter"));
        g.setGradePoints(rs.getDouble("grade_points")); g.setRemarks(rs.getString("remarks"));
        g.setStudentName(rs.getString("student_name")); g.setCourseCode(rs.getString("course_code"));
        g.setCourseTitle(rs.getString("course_title")); g.setSemesterName(rs.getString("semester_name"));
        return g;
    }
}
