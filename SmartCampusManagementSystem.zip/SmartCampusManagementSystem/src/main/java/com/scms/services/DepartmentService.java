package com.scms.services;

import com.scms.database.DBConnection;
import com.scms.models.Department;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentService {

    public List<Department> getAll() {
        List<Department> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM departments ORDER BY name")) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public Department getById(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("SELECT * FROM departments WHERE id=?")) {
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) return mapRow(rs);
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean add(Department d) {
        String sql = "INSERT INTO departments (code, name, head_name, description) VALUES (?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, d.getCode()); st.setString(2, d.getName());
            st.setString(3, d.getHeadName()); st.setString(4, d.getDescription());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean update(Department d) {
        String sql = "UPDATE departments SET code=?, name=?, head_name=?, description=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement(sql)) {
            st.setString(1, d.getCode()); st.setString(2, d.getName());
            st.setString(3, d.getHeadName()); st.setString(4, d.getDescription());
            st.setInt(5, d.getId());
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean delete(int id) {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement st = c.prepareStatement("DELETE FROM departments WHERE id=?")) {
            st.setInt(1, id);
            return st.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    private Department mapRow(ResultSet rs) throws SQLException {
        Department d = new Department();
        d.setId(rs.getInt("id")); d.setCode(rs.getString("code"));
        d.setName(rs.getString("name")); d.setHeadName(rs.getString("head_name"));
        d.setDescription(rs.getString("description"));
        return d;
    }
}
