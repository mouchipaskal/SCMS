package com.scms.reports;

import com.scms.models.Grade;
import com.scms.models.Student;
import com.scms.services.GradeService;
import com.scms.services.StudentService;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PDFReportGenerator {

    private static final GradeService gradeService = new GradeService();
    private static final StudentService studentService = new StudentService();

    public static void generateTranscript(int studentId, Stage owner) {
        Student student = studentService.getById(studentId);
        if (student == null) return;

        List<Grade> grades = gradeService.getByStudent(studentId);
        double cgpa = gradeService.calculateCGPA(studentId);

        FileChooser fc = new FileChooser();
        fc.setTitle("Save Transcript");
        fc.setInitialFileName(student.getStudentNumber() + "_transcript.pdf");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
        File file = fc.showSaveDialog(owner);
        if (file == null) return;

        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            PDType1Font boldFont   = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
            PDType1Font normalFont = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

            try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
                float width = page.getMediaBox().getWidth();
                float y = 750;

                // Header
                cs.beginText();
                cs.setFont(boldFont, 20);
                cs.newLineAtOffset((width - 300) / 2, y);
                cs.showText("Smart Campus Management System");
                cs.endText();

                y -= 25;
                cs.beginText();
                cs.setFont(boldFont, 14);
                cs.newLineAtOffset((width - 160) / 2, y);
                cs.showText("OFFICIAL TRANSCRIPT");
                cs.endText();

                // Line
                y -= 15;
                cs.setLineWidth(1.5f);
                cs.moveTo(50, y); cs.lineTo(width - 50, y); cs.stroke();

                // Student info
                y -= 25;
                writeText(cs, normalFont, 12, 50, y, "Student Name  : " + student.getFullName());
                y -= 18;
                writeText(cs, normalFont, 12, 50, y, "Student Number: " + student.getStudentNumber());
                y -= 18;
                writeText(cs, normalFont, 12, 50, y, "Department    : " + (student.getDepartmentName() != null ? student.getDepartmentName() : "N/A"));
                y -= 18;
                writeText(cs, normalFont, 12, 50, y, "Admission Year: " + student.getAdmissionYear());
                y -= 18;
                writeText(cs, normalFont, 12, 50, y, "Date Generated: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")));

                y -= 20;
                cs.moveTo(50, y); cs.lineTo(width - 50, y); cs.stroke();

                // Table header
                y -= 20;
                cs.setFont(boldFont, 11);
                writeText(cs, boldFont, 11, 50,  y, "Course Code");
                writeText(cs, boldFont, 11, 140, y, "Course Title");
                writeText(cs, boldFont, 11, 320, y, "Semester");
                writeText(cs, boldFont, 11, 430, y, "CA");
                writeText(cs, boldFont, 11, 460, y, "Exam");
                writeText(cs, boldFont, 11, 495, y, "Total");
                writeText(cs, boldFont, 11, 530, y, "Grade");

                y -= 5;
                cs.moveTo(50, y); cs.lineTo(width - 50, y); cs.stroke();

                // Grade rows
                for (Grade g : grades) {
                    y -= 18;
                    if (y < 60) break;
                    writeText(cs, normalFont, 10, 50,  y, safe(g.getCourseCode()));
                    writeText(cs, normalFont, 10, 140, y, truncate(safe(g.getCourseTitle()), 22));
                    writeText(cs, normalFont, 10, 320, y, truncate(safe(g.getSemesterName()), 14));
                    writeText(cs, normalFont, 10, 430, y, String.format("%.1f", g.getCaScore()));
                    writeText(cs, normalFont, 10, 460, y, String.format("%.1f", g.getExamScore()));
                    writeText(cs, normalFont, 10, 495, y, String.format("%.1f", g.getTotalScore()));
                    writeText(cs, normalFont, 10, 530, y, safe(g.getGradeLetter()));
                }

                // CGPA footer
                y -= 30;
                cs.moveTo(50, y); cs.lineTo(width - 50, y); cs.stroke();
                y -= 20;
                writeText(cs, boldFont, 13, 50, y, String.format("Cumulative GPA (CGPA): %.2f / 4.00", cgpa));
                y -= 18;
                writeText(cs, boldFont, 11, 50, y, "Academic Standing: " + standingFromCGPA(cgpa));
            }

            doc.save(file);
            System.out.println("[PDF] Transcript saved: " + file.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void writeText(PDPageContentStream cs, PDType1Font font, float size, float x, float y, String text) throws Exception {
        cs.beginText();
        cs.setFont(font, size);
        cs.newLineAtOffset(x, y);
        cs.showText(text);
        cs.endText();
    }

    private static String safe(String s) { return s != null ? s : ""; }
    private static String truncate(String s, int max) { return s.length() > max ? s.substring(0, max) + "…" : s; }
    private static String standingFromCGPA(double cgpa) {
        if (cgpa >= 3.5) return "First Class";
        if (cgpa >= 3.0) return "Second Class Upper";
        if (cgpa >= 2.0) return "Second Class Lower";
        if (cgpa >= 1.0) return "Third Class";
        return "Fail";
    }
}
