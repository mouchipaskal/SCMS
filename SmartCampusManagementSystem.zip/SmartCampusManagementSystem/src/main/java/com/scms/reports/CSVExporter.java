package com.scms.reports;

import com.scms.models.Grade;
import com.scms.models.Student;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

public class CSVExporter {

    public static void exportStudents(List<Student> students, Stage owner) {
        File file = chooseSaveFile(owner, "students_export.csv");
        if (file == null) return;
        try (CSVPrinter printer = new CSVPrinter(new FileWriter(file),
                CSVFormat.DEFAULT.withHeader("ID", "Student No", "Full Name", "Gender", "Department", "Email", "Phone", "Admission Year", "Status"))) {
            for (Student s : students) {
                printer.printRecord(s.getId(), s.getStudentNumber(), s.getFullName(), s.getGender(),
                        s.getDepartmentName(), s.getEmail(), s.getPhone(), s.getAdmissionYear(),
                        s.isActive() ? "Active" : "Inactive");
            }
            System.out.println("[CSV] Students exported to: " + file.getAbsolutePath());
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void exportGrades(List<Grade> grades, Stage owner) {
        File file = chooseSaveFile(owner, "grades_export.csv");
        if (file == null) return;
        try (CSVPrinter printer = new CSVPrinter(new FileWriter(file),
                CSVFormat.DEFAULT.withHeader("Student", "Course Code", "Course Title", "Semester", "CA", "Exam", "Total", "Grade", "Grade Points"))) {
            for (Grade g : grades) {
                printer.printRecord(g.getStudentName(), g.getCourseCode(), g.getCourseTitle(),
                        g.getSemesterName(), g.getCaScore(), g.getExamScore(), g.getTotalScore(),
                        g.getGradeLetter(), g.getGradePoints());
            }
            System.out.println("[CSV] Grades exported to: " + file.getAbsolutePath());
        } catch (Exception e) { e.printStackTrace(); }
    }

    private static File chooseSaveFile(Stage owner, String defaultName) {
        FileChooser fc = new FileChooser();
        fc.setTitle("Save CSV Export");
        fc.setInitialFileName(defaultName);
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        return fc.showSaveDialog(owner);
    }
}
