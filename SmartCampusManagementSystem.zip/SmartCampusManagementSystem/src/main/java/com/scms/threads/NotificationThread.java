package com.scms.threads;

import com.scms.services.AttendanceService;
import com.scms.services.NotificationService;
import com.scms.services.StudentService;
import com.scms.models.Student;
import com.scms.utils.SceneManager;
import javafx.application.Platform;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class NotificationThread {

    private static ScheduledExecutorService executor;
    private static final NotificationService notifService = new NotificationService();
    private static final AttendanceService attendanceService = new AttendanceService();
    private static final StudentService studentService = new StudentService();

    public static void start() {
        executor = Executors.newScheduledThreadPool(2);

        // Task 1: Check attendance alerts every 5 minutes
        executor.scheduleAtFixedRate(() -> {
            try {
                checkAttendanceAlerts();
            } catch (Exception e) {
                System.err.println("[NotificationThread] Error: " + e.getMessage());
            }
        }, 0, 5, TimeUnit.MINUTES);

        // Task 2: System health broadcast every 30 minutes
        executor.scheduleAtFixedRate(() -> {
            try {
                checkSystemNotifications();
            } catch (Exception e) {
                System.err.println("[NotificationThread] System check error: " + e.getMessage());
            }
        }, 1, 30, TimeUnit.MINUTES);

        System.out.println("[NotificationThread] Background notification service started.");
    }

    public static void stop() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
            System.out.println("[NotificationThread] Notification service stopped.");
        }
    }

    private static void checkAttendanceAlerts() {
        if (SceneManager.getCurrentUser() == null) return;
        List<Student> students = studentService.getAll();
        for (Student s : students) {
            // Check across all courses (simplified: if user object links to a student)
            // In production, iterate through registered courses
            System.out.println("[NotificationThread] Checked attendance for: " + s.getFullName());
        }
    }

    private static void checkSystemNotifications() {
        System.out.println("[NotificationThread] System health check completed at " + java.time.LocalTime.now());
    }
}
