# Smart Campus Management System (SCMS)

A JavaFX desktop application for managing campus operations including student/lecturer administration, course management, attendance tracking (including QR-based), grades, registrations, timetabling, and reporting.

## Tech Stack

| Component | Technology |
|-----------|------------|
| Language | Java 21 |
| UI Framework | JavaFX 21 (FXML + CSS) |
| Build Tool | Maven 3.x |
| Database | MySQL 8.x |
| JDBC Driver | MySQL Connector/J 8.3.0 |
| Password Hashing | jBCrypt 0.4 (BCrypt, rounds=12) |
| PDF Reports | Apache PDFBox 3.0.1 |
| CSV Export | Apache Commons CSV 1.10.0 |
| QR Codes | ZXing (core + javase) 3.5.3 |

## Project Structure

```
src/main/java/com/scms/
├── MainApp.java                  # Application entry point
├── database/
│   └── DBConnection.java         # MySQL connection (singleton, root/Skelm089)
├── models/
│   ├── User.java                 # users table (auth, roles: ADMIN/LECTURER/STUDENT)
│   ├── Student.java              # students table (1:1 with users via user_id)
│   ├── Lecturer.java             # lecturers table (1:1 with users via user_id)
│   ├── Course.java               # courses table (linked to dept, semester, lecturer)
│   ├── Department.java           # departments table
│   ├── Semester.java             # semesters table
│   ├── Room.java                 # rooms table
│   ├── Registration.java         # registrations table (student_enrolls_in_course)
│   ├── Attendance.java           # attendance table
│   ├── Grade.java                # grades table (total_score is computed column)
│   ├── Timetable.java            # timetable table
│   ├── QRSession.java            # qr_sessions table
│   ├── Notification.java         # notifications table
│   └── ActivityLog.java          # activity_logs table
├── services/
│   ├── UserService.java          # Auth + user CRUD + BCrypt hashing
│   ├── StudentService.java       # Student CRUD + getByUserId
│   ├── LecturerService.java      # Lecturer CRUD + getByUserId
│   ├── CourseService.java        # Course CRUD + getByLecturer + getBySemester
│   ├── DepartmentService.java    # Department CRUD
│   ├── SemesterService.java      # Semester CRUD + getActive
│   ├── RoomService.java          # Room CRUD
│   ├── RegistrationService.java  # Registration CRUD + getByStudent + getByCourse
│   ├── AttendanceService.java    # Attendance CRUD
│   ├── GradeService.java         # Grade CRUD + calculateCGPA + computeGradeLetter
│   ├── TimetableService.java     # Timetable CRUD
│   ├── QRAttendanceService.java  # QR session generation + validation
│   ├── NotificationService.java  # Notification CRUD
│   └── ActivityLogService.java   # Activity log CRUD
├── controllers/
│   ├── SplashController.java     # Splash screen + auto-start NotificationThread
│   ├── LoginController.java      # Login form (BCrypt verify + role routing)
│   ├── AdminDashboardController.java
│   ├── LecturerDashboardController.java
│   ├── StudentDashboardController.java
│   ├── StudentManagementController.java
│   ├── LecturerManagementController.java
│   ├── DepartmentManagementController.java
│   ├── CourseManagementController.java
│   ├── RegistrationController.java
│   ├── AttendanceController.java
│   ├── GradeManagementController.java
│   ├── TimetableController.java
│   ├── QRAttendanceController.java
│   ├── StudentQRAttendanceController.java
│   ├── ReportsController.java
│   ├── NotificationsController.java
│   ├── SettingsController.java   # Profile + password change + dark/light toggle
│   └── SceneManager              # View switching + theme application
├── utils/
│   ├── BCryptUtil.java           # BCrypt.hashpw / checkpw wrapper
│   ├── AlertUtil.java            # JavaFX alert helpers
│   ├── ValidationUtil.java       # Input validation helpers
│   ├── QRCodeUtil.java           # QR image generation
│   ├── ActivityLogger.java       # Async activity log writer
│   └── SceneManager.java         # FXML loader + stylesheet manager
├── reports/
│   ├── PDFReportGenerator.java   # PDF report generation (PDFBox)
│   └── CSVExporter.java           # CSV export (Apache Commons CSV)
└── threads/
    └── NotificationThread.java    # Background notification poller

src/main/resources/com/scms/
├── views/                        # FXML layouts (one per screen)
│   ├── splash.fxml
│   ├── login.fxml
│   ├── admin-dashboard.fxml
│   ├── lecturer-dashboard.fxml
│   ├── student-dashboard.fxml
│   ├── student-management.fxml
│   ├── lecturer-management.fxml
│   ├── department-management.fxml
│   ├── course-management.fxml
│   ├── registration-management.fxml
│   ├── attendance-management.fxml
│   ├── grade-management.fxml
│   ├── timetable-management.fxml
│   ├── qr-attendance.fxml
│   ├── student-qr-attendance.fxml
│   ├── reports.fxml
│   ├── notifications.fxml
│   └── settings.fxml
└── styles/
    ├── common.css                # Structural/layout rules (theme-agnostic)
    ├── dark-theme.css            # Dark mode colors (default)
    └── light-theme.css           # Light mode colors

database.sql                       # Full schema + seed data
pom.xml                            # Maven config
```

## Database Schema

### Core Tables

| Table | Purpose |
|-------|---------|
| `users` | Authentication + roles. Password stored as BCrypt hash. |
| `students` | Student profile (1:1 with `users.user_id`) |
| `lecturers` | Lecturer profile (1:1 with `users.user_id`) |
| `departments` | Academic departments |
| `courses` | Course catalog (FK to dept, semester, lecturer) |
| `semesters` | Academic periods (one marked `is_active=TRUE`) |
| `rooms` | Campus rooms |
| `registrations` | Student course enrollments |
| `attendance` | Daily attendance records |
| `grades` | CA + exam scores (total_score is a generated/stored column) |
| `timetable` | Course schedule slots |
| `qr_sessions` | Active QR attendance sessions |
| `notifications` | User notifications |
| `activity_logs` | System audit trail |

### Key Relationships

```
users (id) ──1:1── students (user_id)
users (id) ──1:1── lecturers (user_id)
departments (id) ──1:N── students (department_id)
departments (id) ──1:N── lecturers (department_id)
departments (id) ──1:N── courses (department_id)
semesters (id) ──1:N── courses (semester_id)
lecturers (id) ──1:N── courses (lecturer_id)
students (id) ──1:N── registrations (student_id)
courses (id) ──1:N── registrations (course_id)
```

## Authentication

### Login Flow

1. User enters username + password on `LoginController`.
2. `UserService.login()` queries `SELECT * FROM users WHERE username=? AND is_active=TRUE`.
3. Password verified with `BCryptUtil.verify(plainText, storedHash)`.
4. On success: `SceneManager.setCurrentUser(user)` and route by role:
   - `ADMIN` → `admin-dashboard.fxml`
   - `LECTURER` → `lecturer-dashboard.fxml`
   - `STUDENT` → `student-dashboard.fxml`
5. On failure: error label shows "Invalid credentials or account is inactive."

### Lecturer/Student Dashboard Lookup

On login, dashboards look up their profile via:

- `LecturerDashboardController`: `lecturerService.getByUserId(user.getId())`
- `StudentDashboardController`: `studentService.getByUserId(user.getId())`

These query the `lecturers` / `students` tables where `user_id = <current logged-in user id>`. If no row matches, the dashboard shows empty data.

### Password Storage

- All passwords hashed with BCrypt (cost factor 12).
- Each user must have a **unique** hash corresponding to their own password.
- On registration (from management screens), `UserService.createUser()` inserts the user and uses `RETURN_GENERATED_KEYS` to capture the auto-generated `id` so the new lecturer/student record can be linked with the correct `user_id`.

## Default Credentials

| Username | Password | Role |
|----------|----------|------|
| `admin` | `Admin@123` | ADMIN |
| `lecturer1` | `Lecturer@123` | LECTURER |
| `student1` | `Student@123` | STUDENT |

> Re-run `database.sql` to reset these at any time. The script uses `INSERT IGNORE`, so it is safe to re-run on an existing database.

## Themes

- **Default: Dark mode** (`darkMode = true` in `SceneManager`).
- Switchable at runtime from `Settings` screen via a toggle button.
- Theme switching clears all stylesheets and re-applies `common.css` + the selected theme CSS in that order.

### CSS Architecture

- `common.css` → **structure only**: padding, sizes, fonts, shadow, border-radius. Contains no colors and no text-fill rules.
- `dark-theme.css` → **all dark-mode colors**.
- `light-theme.css` → **all light-mode colors**.

Because the theme file is loaded after `common.css`, its color rules override any overlapping declarations. This prevents invisible text caused by mismatched CSS cascade.

## Notifications

A background `NotificationThread` starts on app launch (from `SplashController`). It periodically checks for pending notifications for the current user and updates the notification count/UI.

## Reports

- **PDF**: `PDFReportGenerator` uses Apache PDFBox.
- **CSV**: `CSVExporter` uses Apache Commons CSV (currently exports student lists).

## QR Attendance

- Lecturers generate QR sessions via `QRAttendanceController` (`qr-attendance.fxml`).
- Students scan/enter the token via `StudentQRAttendanceController` (`student-qr-attendance.fxml`).
- `QRAttendanceService` validates tokens against `qr_sessions` and marks attendance.

## How to Build & Run

```bash
# Ensure MySQL is running and database.sql has been executed
mysql -u root -p < database.sql

# Build and run
mvn clean compile
mvn javafx:run
```

## Known Issues & Fixes Applied

| Issue | Fix |
|-------|-----|
| Default credentials all had the same BCrypt hash | Regenerated distinct hashes per password in `database.sql` |
| `TextArea.getText()` returns null on empty field causing NPE in CourseManagement | Added null guard in `buildFromForm()` |
| Newly added lecturers/students showed empty dashboards | `UserService.createUser()` was using a cross-connection `LAST_INSERT_ID()`. Fixed to use `RETURN_GENERATED_KEYS` and `u.setId()` directly |
| Stat card numbers were invisible in some theme states | Moved all color rules into theme-specific CSS files; added explicit stat-card color overrides |
| Default theme was light; requested to default to dark | Changed `darkMode = true` in `SceneManager` |
| Theme CSS had hardcoded colors in common.css | Stripped all colors from `common.css`; rewrote both theme files with full coverage |

## Requirements

- JDK 21
- MySQL 8.x
- Maven 3.8+
